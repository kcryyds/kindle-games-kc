#!/bin/sh
# Name: 游戏合集
# Author: Custom
# Icon: data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAABBklEQVR42u3bSw6DMAxAQd//0nTRNSqo+dmet0YgRkEKkMSlxwUCWLBgwYIFCwEsWLBgwYKFABYsWLBgwUIACxYsWLBgIYAFCxYsWHenyNMerMjZaqzI3FKsSN46rMgfrPOwokSwYMFqgRU9ggUL1j83mRVrGffwC5XFmvEcwIIFa+RdwTKyYMEa/17aap51yD+0h6f6eVgLrFEDsDvWq6vDggVrw/epPp9oko0sWLC6Yh00z0qBdcoMPhdW6x8WsJph5Q0WLFhFsDp4WcwGC1YprNpeNg1sxarqNX5pd1WvKevg65FN3DRQA27FpgHBggULFixYggULFixYsAQLFixYsGDp2wfbsRM2TH+zZQAAAABJRU5ErkJggg==

APP_ID="com.kindlegames.v1"

# 检查是否已有实例
has_instance() {
  for proc_dir in /proc/[0-9]*; do
    [ -r "$proc_dir/cmdline" ] || continue
    proc_cmd="$(tr '\000' ' ' < "$proc_dir/cmdline" 2>/dev/null)"
    case "$proc_cmd" in
      *mesquite*"-l $APP_ID"*) return 0 ;;
    esac
  done
  return 1
}

if has_instance; then
  lipc-set-prop com.lab126.appmgrd stop "app://$APP_ID" >/dev/null 2>&1 || true
  sleep 1
fi

lipc-set-prop com.lab126.appmgrd start "app://$APP_ID" >/dev/null 2>&1 || true
exit 0
