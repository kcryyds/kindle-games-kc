#!/bin/sh
# 游戏合集守护进程 - HTTP本地端口通信
BASE="/mnt/us/kindle_games"
LOG_FILE="$BASE/daemon.log"
HTTP_PORT=12348
HIGH_SCORES="$BASE/highscores.txt"

log() { echo "$(date '+%H:%M:%S') $*" >> "$LOG_FILE"; }

mkdir -p "$BASE"
touch "$HIGH_SCORES"
log "守护进程启动，端口=$HTTP_PORT"

# HTTP 主循环
while true; do
  REQUEST=$(nc -l -p "$HTTP_PORT" -w 30 2>/dev/null)
  if [ -z "$REQUEST" ]; then
    continue
  fi

  # 解析请求体（POST data）
  BODY=$(echo "$REQUEST" | sed -n '/^\r*$/,$p' | tail -n +2 | tr -d '\r')
  CMD=$(echo "$BODY" | sed 's/^cmd=//' | sed 's/&.*//')
  # URL解码
  CMD=$(echo "$CMD" | sed 's/+/ /g;s/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\x\1/g' | printf '%b' "$(cat)")

  log "收到命令: $CMD"

  ACTION=$(echo "$CMD" | cut -d: -f1)
  PARAM=$(echo "$CMD" | cut -d: -f2-)

  case "$ACTION" in
    save)
      # 保存高分: save:游戏名:分数
      GAME=$(echo "$PARAM" | cut -d: -f1)
      SCORE=$(echo "$PARAM" | cut -d: -f2)
      # 更新高分
      if grep -q "^$GAME:" "$HIGH_SCORES" 2>/dev/null; then
        OLD=$(grep "^$GAME:" "$HIGH_SCORES" | head -1 | cut -d: -f2)
        if [ "$SCORE" -gt "$OLD" ] 2>/dev/null; then
          sed -i "s/^$GAME:.*/$GAME:$SCORE/" "$HIGH_SCORES"
        fi
      else
        echo "$GAME:$SCORE" >> "$HIGH_SCORES"
      fi
      log "保存高分: $GAME=$SCORE"
      ;;
    exit)
      # 退出应用
      lipc-set-prop com.lab126.appmgrd stop "app://com.kindlegames.v1" >/dev/null 2>&1 || true
      ;;
  esac

  # 返回HTTP响应
  printf 'HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK' | nc -l -p "$HTTP_PORT" -w 2 >/dev/null 2>&1 &
done
