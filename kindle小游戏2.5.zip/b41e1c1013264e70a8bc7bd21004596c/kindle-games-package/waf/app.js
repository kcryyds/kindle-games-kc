(function(){
"use strict";

/* ==================== 通用工具 ==================== */
var HTTP_PORT = 12348;
var HTTP_URL = "http://127.0.0.1:" + HTTP_PORT + "/";
var currentGame = null;

function $(id){ return document.getElementById(id); }
function showPage(id){
  var pages = document.getElementsByClassName("page");
  for(var i=0;i<pages.length;i++) pages[i].className = "page";
  $(id).className = "page active";
}
function sendCommand(cmd){
  try{
    var xhr = new XMLHttpRequest();
    xhr.open("POST", HTTP_URL, true);
    xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    xhr.send("cmd="+encodeURIComponent(cmd));
  }catch(e){}
}
function showModal(title, text, btnText, callback){
  var overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  overlay.innerHTML = '<div class="modal-box"><div class="modal-title">'+title+'</div>'
    +'<div class="modal-text">'+text+'</div>'
    +'<button class="btn" id="modalBtn">'+(btnText||"确定")+'</button></div>';
  document.body.appendChild(overlay);
  $("modalBtn").onclick = function(){
    document.body.removeChild(overlay);
    if(callback) callback();
  };
}
function getHigh(key){try{return parseInt(localStorage.getItem("kg_high_"+key)||"0");}catch(e){return 0;}}
function setHigh(key,val){try{if(val>parseInt(localStorage.getItem("kg_high_"+key)||"0"))localStorage.setItem("kg_high_"+key,val);}catch(e){}}
function shuffle(arr){
  for(var i=arr.length-1;i>0;i--){
    var j=Math.floor(Math.random()*(i+1));
    var t=arr[i];arr[i]=arr[j];arr[j]=t;
  }
  return arr;
}

/* ==================== 游戏列表 ==================== */
var GAMES = [
  { id:"gomoku",    name:"五子棋",   icon:"\u2694", desc:"人机对战 / 双人对战" },
  { id:"tictactoe", name:"井字棋",   icon:"\u2B55", desc:"人机对战 / 双人对战" },
  { id:"othello",   name:"黑白棋",   icon:"\u26AB", desc:"人机对战 / 双人对战" },
  { id:"2048",      name:"2048",     icon:"2048",   desc:"滑动合并数字" },
  { id:"snake",     name:"贪吃蛇",   icon:"S", desc:"吃食物变长" },
  { id:"minesweeper",name:"扫雷",    icon:"*", desc:"排除所有地雷" },
  { id:"sudoku",    name:"数独",     icon:"#", desc:"填入1-9不重复" },
  { id:"tetris",    name:"俄罗斯方块",icon:"\u25A3", desc:"消行得分" },
  { id:"sokoban",   name:"推箱子",   icon:"\u25A1", desc:"把箱子推到目标点" },
  { id:"breakout",  name:"打砖块",   icon:"=", desc:"打碎所有砖块" },
  { id:"memory",    name:"记忆翻牌", icon:"?", desc:"配对相同的牌" },
  { id:"puzzle",    name:"华容道",   icon:"15", desc:"滑块数字拼图" },
  { id:"pet",       name:"电子宠物", icon:"P", desc:"喂食玩耍清洁睡觉" },
  { id:"bullscows", name:"迷宫",   icon:"M", desc:"从起点走到终点" },
  { id:"dino",      name:"小恐龙", icon:"D", desc:"跳跃躲避仙人掌" },
  { id:"shell",     name:"猜瓶子", icon:"O", desc:"猜球在哪个杯子下" },
  { id:"pipe",      name:"水管连接", icon:"~", desc:"旋转水管接通水源 20关" },
  { id:"go",        name:"围棋",   icon:"\u26C6", desc:"9x9 人机/双人" },
  { id:"cookie",    name:"饼干点击器", icon:"C", desc:"点饼干买升级 有惊喜" },
  { id:"whack",     name:"打地鼠",     icon:"W", desc:"30秒限时 金地鼠3分 炸弹扣分" },
  { id:"goldminer", name:"黄金矿工",   icon:"G", desc:"抓金块钻石 多关卡目标金额" },
  { id:"catchgold", name:"接元宝",   icon:"Y", desc:"滑动接元宝 躲炸弹 3条命" }
];

/* ==================== 主菜单 ==================== */
function renderMenu(){
  var list = $("gameList");
  var html = "";
  for(var i=0;i<GAMES.length;i++){
    var g = GAMES[i];
    html += '<button class="game-item" data-id="'+g.id+'">'
      + '<span class="game-icon">'+g.icon+'</span>'+g.name
      + '<span class="game-desc">'+g.desc+'</span></button>';
  }
  list.innerHTML = html;
  var items = list.getElementsByClassName("game-item");
  for(var j=0;j<items.length;j++){
    items[j].onclick = function(){
      var id = this.getAttribute("data-id");
      startGame(id);
    };
  }
}

function startGame(id){
  for(var i=0;i<GAMES.length;i++){
    if(GAMES[i].id === id){
      $("gameTitle").textContent = GAMES[i].name;
      break;
    }
  }
  $("gameScore").textContent = "";
  $("gameControls").innerHTML = "";
  $("gameBody").innerHTML = "";
  currentGame = id;
  showPage("gamePage");
  if(GAME_INITS[id]) GAME_INITS[id]();
}

function backToMenu(){
  if(GAME_CLEANUPS[currentGame]) GAME_CLEANUPS[currentGame]();
  currentGame = null;
  $("gameBody").innerHTML = "";
  $("gameControls").innerHTML = "";
  showPage("menuPage");
}

function exitApp(){
  sendCommand("exit");
}

var GAME_INITS = {};
var GAME_CLEANUPS = {};

/* ==================== 1. 五子棋 ==================== */
GAME_INITS.gomoku = function(){
  var SIZE = 15;
  var board = [];
  var mode = "pve"; // pve | pvp
  var currentPlayer = 1; // 1=黑(人), 2=白(AI/玩家2)
  var gameOver = false;

  for(var i=0;i<SIZE;i++){ board[i]=[]; for(var j=0;j<SIZE;j++) board[i][j]=0; }

  function render(){
    var html = '<div class="board" style="font-size:0;">';
    for(var r=0;r<SIZE;r++){
      html += '<div class="board-row">';
      for(var c=0;c<SIZE;c++){
        var v = board[r][c];
        var bg = v===1 ? '#000' : (v===2 ? '#fff' : '#fff');
        var border = v===2 ? '2px solid #000' : '1px solid #ccc';
        html += '<div class="cell" data-r="'+r+'" data-c="'+c+'" style="width:30px;height:30px;background:'+bg+';border:'+border+';"></div>';
      }
      html += '</div>';
    }
    html += '</div>';
    $("gameBody").innerHTML = html;
    var cells = $("gameBody").getElementsByClassName("cell");
    for(var i=0;i<cells.length;i++){
      cells[i].onclick = function(){
        if(gameOver) return;
        var r = parseInt(this.getAttribute("data-r"));
        var c = parseInt(this.getAttribute("data-c"));
        if(board[r][c]!==0) return;
        makeMove(r,c,currentPlayer);
        if(checkWin(r,c,currentPlayer)){
          gameOver = true;
          render();
          showModal("游戏结束", (currentPlayer===1?"黑棋":"白棋")+"获胜！", "再来一局", function(){ startGame("gomoku"); });
          return;
        }
        currentPlayer = currentPlayer===1?2:1;
        render();
        if(mode==="pve" && currentPlayer===2 && !gameOver){
          setTimeout(aiMove, 300);
        }
      };
    }
  }

  function makeMove(r,c,p){ board[r][c]=p; }

  function checkWin(r,c,p){
    var dirs = [[0,1],[1,0],[1,1],[1,-1]];
    for(var d=0;d<4;d++){
      var count=1;
      for(var s=1;s<5;s++){ var nr=r+dirs[d][0]*s, nc=c+dirs[d][1]*s; if(nr<0||nr>=SIZE||nc<0||nc>=SIZE||board[nr][nc]!==p) break; count++; }
      for(var s=1;s<5;s++){ var nr=r-dirs[d][0]*s, nc=c-dirs[d][1]*s; if(nr<0||nr>=SIZE||nc<0||nc>=SIZE||board[nr][nc]!==p) break; count++; }
      if(count>=5) return true;
    }
    return false;
  }

  function aiMove(){
    // 简单AI：找得分最高的位置
    var bestR=7, bestC=7, bestScore=-1;
    for(var r=0;r<SIZE;r++){
      for(var c=0;c<SIZE;c++){
        if(board[r][c]!==0) continue;
        var score = evalPosition(r,c,2)*1.1 + evalPosition(r,c,1);
        if(score > bestScore){ bestScore=score; bestR=r; bestC=c; }
      }
    }
    makeMove(bestR,bestC,2);
    if(checkWin(bestR,bestC,2)){
      gameOver = true;
      render();
      showModal("游戏结束", "白棋(AI)获胜！", "再来一局", function(){ startGame("gomoku"); });
      return;
    }
    currentPlayer = 1;
    render();
  }

  function evalPosition(r,c,p){
    var dirs = [[0,1],[1,0],[1,1],[1,-1]];
    var total = 0;
    for(var d=0;d<4;d++){
      var count=1, blocked=0;
      for(var s=1;s<5;s++){ var nr=r+dirs[d][0]*s, nc=c+dirs[d][1]*s; if(nr<0||nr>=SIZE||nc<0||nc>=SIZE){blocked++;break;} if(board[nr][nc]===p) count++; else if(board[nr][nc]!==0){blocked++;break;} else break; }
      for(var s=1;s<5;s++){ var nr=r-dirs[d][0]*s, nc=c-dirs[d][1]*s; if(nr<0||nr>=SIZE||nc<0||nc>=SIZE){blocked++;break;} if(board[nr][nc]===p) count++; else if(board[nr][nc]!==0){blocked++;break;} else break; }
      if(count>=5) total += 100000;
      else if(count===4 && blocked===0) total += 10000;
      else if(count===4 && blocked===1) total += 1000;
      else if(count===3 && blocked===0) total += 500;
      else if(count===3 && blocked===1) total += 100;
      else if(count===2 && blocked===0) total += 50;
      else total += count*10;
    }
    return total;
  }

  $("gameControls").innerHTML = '<button class="btn" id="gmPve">人机</button><button class="btn" id="gmPvp">双人</button><button class="btn" id="gmRestart">重开</button>';
  $("gmPve").onclick = function(){ mode="pve"; currentPlayer=1; gameOver=false; for(var i=0;i<SIZE;i++)for(var j=0;j<SIZE;j++)board[i][j]=0; $("gmPve").className="btn active"; $("gmPvp").className="btn"; render(); };
  $("gmPvp").onclick = function(){ mode="pvp"; currentPlayer=1; gameOver=false; for(var i=0;i<SIZE;i++)for(var j=0;j<SIZE;j++)board[i][j]=0; $("gmPvp").className="btn active"; $("gmPve").className="btn"; render(); };
  $("gmRestart").onclick = function(){ startGame("gomoku"); };
  $("gmPve").className="btn active";
  render();
};

/* ==================== 2. 井字棋 ==================== */
GAME_INITS.tictactoe = function(){
  var board = [0,0,0,0,0,0,0,0,0];
  var mode = "pve";
  var current = 1;
  var over = false;

  function render(){
    var html = '<div class="board" style="font-size:0;">';
    for(var r=0;r<3;r++){
      html += '<div class="board-row">';
      for(var c=0;c<3;c++){
        var idx = r*3+c;
        var v = board[idx];
        var text = v===1?'X':(v===2?'O':'');
        html += '<div class="cell" data-idx="'+idx+'" style="width:100px;height:100px;font-size:48px;line-height:96px;border:2px solid #000;">'+text+'</div>';
      }
      html += '</div>';
    }
    html += '</div>';
    $("gameBody").innerHTML = html;
    var cells = $("gameBody").getElementsByClassName("cell");
    for(var i=0;i<cells.length;i++){
      cells[i].onclick = function(){
        if(over) return;
        var idx = parseInt(this.getAttribute("data-idx"));
        if(board[idx]!==0) return;
        board[idx] = current;
        if(checkWin(current)){ over=true; render(); showModal("游戏结束",(current===1?"X":"O")+"获胜！","再来一局",function(){startGame("tictactoe");}); return; }
        if(board.indexOf(0)===-1){ over=true; render(); showModal("平局","棋盘已满","再来一局",function(){startGame("tictactoe");}); return; }
        current = current===1?2:1;
        render();
        if(mode==="pve" && current===2 && !over){ setTimeout(aiMove,300); }
      };
    }
  }

  function checkWin(p){
    var lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    for(var i=0;i<lines.length;i++){
      if(board[lines[i][0]]===p && board[lines[i][1]]===p && board[lines[i][2]]===p) return true;
    }
    return false;
  }

  function aiMove(){
    //  minimax 简化版
    var best = -1, bestScore = -Infinity;
    for(var i=0;i<9;i++){
      if(board[i]===0){
        board[i]=2;
        var s = minimax(board,0,false);
        board[i]=0;
        if(s>bestScore){ bestScore=s; best=i; }
      }
    }
    if(best>=0){
      board[best]=2;
      if(checkWin(2)){ over=true; render(); showModal("游戏结束","O(AI)获胜！","再来一局",function(){startGame("tictactoe");}); return; }
      if(board.indexOf(0)===-1){ over=true; render(); showModal("平局","棋盘已满","再来一局",function(){startGame("tictactoe");}); return; }
      current=1;
      render();
    }
  }

  function minimax(b,depth,isMax){
    if(checkWinArr(b,2)) return 10-depth;
    if(checkWinArr(b,1)) return depth-10;
    if(b.indexOf(0)===-1) return 0;
    if(isMax){
      var best=-Infinity;
      for(var i=0;i<9;i++){ if(b[i]===0){ b[i]=2; best=Math.max(best,minimax(b,depth+1,false)); b[i]=0; } }
      return best;
    } else {
      var best=Infinity;
      for(var i=0;i<9;i++){ if(b[i]===0){ b[i]=1; best=Math.min(best,minimax(b,depth+1,true)); b[i]=0; } }
      return best;
    }
  }
  function checkWinArr(b,p){
    var lines=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    for(var i=0;i<lines.length;i++){ if(b[lines[i][0]]===p&&b[lines[i][1]]===p&&b[lines[i][2]]===p) return true; }
    return false;
  }

  $("gameControls").innerHTML = '<button class="btn" id="ttPve">人机</button><button class="btn" id="ttPvp">双人</button><button class="btn" id="ttRestart">重开</button>';
  $("ttPve").onclick=function(){ mode="pve"; current=1; over=false; board=[0,0,0,0,0,0,0,0,0]; $("ttPve").className="btn active"; $("ttPvp").className="btn"; render(); };
  $("ttPvp").onclick=function(){ mode="pvp"; current=1; over=false; board=[0,0,0,0,0,0,0,0,0]; $("ttPvp").className="btn active"; $("ttPve").className="btn"; render(); };
  $("ttRestart").onclick=function(){ startGame("tictactoe"); };
  $("ttPve").className="btn active";
  render();
};

/* ==================== 3. 黑白棋 ==================== */
GAME_INITS.othello = function(){
  var N=8;
  var board=[];
  var mode="pve";
  var current=1; // 1=黑, 2=白
  var over=false;
  for(var i=0;i<N;i++){ board[i]=[]; for(var j=0;j<N;j++) board[i][j]=0; }
  board[3][3]=2; board[3][4]=1; board[4][3]=1; board[4][4]=2;

  function render(){
    var html='<div class="board" style="font-size:0;background:#ddd;">';
    for(var r=0;r<N;r++){
      html+='<div class="board-row">';
      for(var c=0;c<N;c++){
        var v=board[r][c];
        var bg = v===1?'#000':(v===2?'#fff':'#ddd');
        var border = v===2?'2px solid #000':'1px solid #999';
        var canMove = !over && board[r][c]===0 && getFlips(r,c,current).length>0;
        var style = 'width:52px;height:52px;background:'+bg+';border:'+border+';';
        if(canMove) style += 'box-shadow:inset 0 0 0 3px #000;';
        html+='<div class="cell" data-r="'+r+'" data-c="'+c+'" style="'+style+'"></div>';
      }
      html+='</div>';
    }
    html+='</div>';
    var counts=countPieces();
    $("gameScore").textContent = "黑"+counts[0]+" 白"+counts[1];
    $("gameBody").innerHTML=html;
    var cells=$("gameBody").getElementsByClassName("cell");
    for(var i=0;i<cells.length;i++){
      cells[i].onclick=function(){
        if(over) return;
        var r=parseInt(this.getAttribute("data-r"));
        var c=parseInt(this.getAttribute("data-c"));
        var flips=getFlips(r,c,current);
        if(flips.length===0) return;
        board[r][c]=current;
        for(var f=0;f<flips.length;f++) board[flips[f][0]][flips[f][1]]=current;
        current=current===1?2:1;
        // 跳过无棋可下的一方
        if(!hasAnyMove(current)){ current=current===1?2:1; if(!hasAnyMove(current)){ over=true; } }
        render();
        if(over){ var ct=countPieces(); var winner=ct[0]>ct[1]?"黑棋":(ct[1]>ct[0]?"白棋":"平局"); showModal("游戏结束",winner+"获胜！黑"+ct[0]+"白"+ct[1],"再来一局",function(){startGame("othello");}); return; }
        if(mode==="pve"&&current===2&&!over){ setTimeout(aiMove,300); }
      };
    }
  }

  function getFlips(r,c,p){
    if(board[r][c]!==0) return [];
    var dirs=[[0,1],[0,-1],[1,0],[-1,0],[1,1],[1,-1],[-1,1],[-1,-1]];
    var flips=[];
    for(var d=0;d<8;d++){
      var temp=[];
      var nr=r+dirs[d][0], nc=c+dirs[d][1];
      while(nr>=0&&nr<N&&nc>=0&&nc<N&&board[nr][nc]!==0&&board[nr][nc]!==p){
        temp.push([nr,nc]);
        nr+=dirs[d][0]; nc+=dirs[d][1];
      }
      if(nr>=0&&nr<N&&nc>=0&&nc<N&&board[nr][nc]===p&&temp.length>0){
        for(var t=0;t<temp.length;t++) flips.push(temp[t]);
      }
    }
    return flips;
  }

  function hasAnyMove(p){
    for(var r=0;r<N;r++) for(var c=0;c<N;c++) if(getFlips(r,c,p).length>0) return true;
    return false;
  }

  function countPieces(){
    var b=0,w=0;
    for(var r=0;r<N;r++) for(var c=0;c<N;c++){ if(board[r][c]===1)b++; else if(board[r][c]===2)w++; }
    return [b,w];
  }

  function aiMove(){
    var bestR=-1,bestC=-1,bestScore=-Infinity;
    for(var r=0;r<N;r++) for(var c=0;c<N;c++){
      var flips=getFlips(r,c,2);
      if(flips.length===0) continue;
      // 角位权重高
      var score=flips.length;
      if((r===0||r===7)&&(c===0||c===7)) score+=20;
      else if(r===0||r===7||c===0||c===7) score+=5;
      if(score>bestScore){ bestScore=score; bestR=r; bestC=c; }
    }
    if(bestR>=0){
      var flips=getFlips(bestR,bestC,2);
      board[bestR][bestC]=2;
      for(var f=0;f<flips.length;f++) board[flips[f][0]][flips[f][1]]=2;
      current=1;
      if(!hasAnyMove(1)){ current=2; if(!hasAnyMove(2)) over=true; }
      render();
      if(over){ var ct=countPieces(); var winner=ct[0]>ct[1]?"黑棋":(ct[1]>ct[0]?"白棋":"平局"); showModal("游戏结束",winner+"获胜！","再来一局",function(){startGame("othello");}); }
    }
  }

  $("gameControls").innerHTML='<button class="btn" id="otPve">人机</button><button class="btn" id="otPvp">双人</button><button class="btn" id="otRestart">重开</button>';
  $("otPve").onclick=function(){ mode="pve"; resetBoard(); $("otPve").className="btn active"; $("otPvp").className="btn"; };
  $("otPvp").onclick=function(){ mode="pvp"; resetBoard(); $("otPvp").className="btn active"; $("otPve").className="btn"; };
  $("otRestart").onclick=function(){ startGame("othello"); };
  function resetBoard(){ for(var i=0;i<N;i++)for(var j=0;j<N;j++)board[i][j]=0; board[3][3]=2;board[3][4]=1;board[4][3]=1;board[4][4]=2; current=1; over=false; render(); }
  $("otPve").className="btn active";
  render();
};

/* ==================== 4. 2048 ==================== */
GAME_INITS["2048"] = function(){
  var N=4;
  var grid=[];
  var score=0;
  var over=false;

  function init(){
    grid=[];
    for(var i=0;i<N;i++){ grid[i]=[]; for(var j=0;j<N;j++) grid[i][j]=0; }
    score=0; over=false;
    addTile(); addTile();
  }

  function addTile(){
    var empty=[];
    for(var r=0;r<N;r++) for(var c=0;c<N;c++) if(grid[r][c]===0) empty.push([r,c]);
    if(empty.length===0) return;
    var pos=empty[Math.floor(Math.random()*empty.length)];
    grid[pos[0]][pos[1]] = Math.random()<0.9?2:4;
  }

  function render(){
    var html='<div class="board" style="font-size:0;background:#ccc;padding:4px;">';
    for(var r=0;r<N;r++){
      html+='<div class="board-row">';
      for(var c=0;c<N;c++){
        var v=grid[r][c];
        var bg = v===0?'#eee':'#000';
        var color = v===0?'#ccc':'#fff';
        var fs = v>=1024?'18px':(v>=128?'22px':'28px');
        html+='<div class="cell" style="width:80px;height:80px;font-size:'+fs+';line-height:76px;background:'+bg+';color:'+color+';border:3px solid #ccc;">'+(v||'')+'</div>';
      }
      html+='</div>';
    }
    html+='</div>';
    $("gameScore").textContent="分数:"+score+" 最高:"+getHigh("snake");
    $("gameBody").innerHTML=html;
  }

  function move(dir){
    if(over) return;
    var moved=false;
    var getVal=function(r,c){
      if(dir==='left') return grid[r][c];
      if(dir==='right') return grid[r][N-1-c];
      if(dir==='up') return grid[c][r];
      if(dir==='down') return grid[N-1-c][r];
    };
    var setVal=function(r,c,v){
      if(dir==='left') grid[r][c]=v;
      else if(dir==='right') grid[r][N-1-c]=v;
      else if(dir==='up') grid[c][r]=v;
      else if(dir==='down') grid[N-1-c][r]=v;
    };

    for(var r=0;r<N;r++){
      var line=[];
      for(var c=0;c<N;c++){ var v=getVal(r,c); if(v!==0) line.push(v); }
      // 合并
      var merged=[];
      for(var i=0;i<line.length;i++){
        if(i<line.length-1 && line[i]===line[i+1]){
          merged.push(line[i]*2);
          score += line[i]*2;
          i++;
        } else {
          merged.push(line[i]);
        }
      }
      while(merged.length<N) merged.push(0);
      for(var c=0;c<N;c++){
        if(getVal(r,c)!==merged[c]) moved=true;
        setVal(r,c,merged[c]);
      }
    }
    if(moved){
      addTile();
      render();
      if(checkWin()){ over=true; showModal("恭喜！","你合成了2048！分数:"+score,"再来一局",function(){startGame("2048");}); }
      else if(checkOver()){ over=true; showModal("游戏结束","没有可移动的方块了。分数:"+score,"再来一局",function(){startGame("2048");}); }
    }
  }

  function checkWin(){
    for(var r=0;r<N;r++) for(var c=0;c<N;c++) if(grid[r][c]>=2048) return true;
    return false;
  }
  function checkOver(){
    for(var r=0;r<N;r++) for(var c=0;c<N;c++){
      if(grid[r][c]===0) return false;
      if(c<N-1 && grid[r][c]===grid[r][c+1]) return false;
      if(r<N-1 && grid[r][c]===grid[r+1][c]) return false;
    }
    return true;
  }

  $("gameControls").innerHTML = '<div class="dpad">'
    +'<div class="dpad-row"><span class="dpad-empty"></span><button class="dpad-btn" data-dir="up">\u25B2</button><span class="dpad-empty"></span></div>'
    +'<div class="dpad-row"><button class="dpad-btn" data-dir="left">\u25C0</button><span class="dpad-empty"></span><button class="dpad-btn" data-dir="right">\u25B6</button></div>'
    +'<div class="dpad-row"><span class="dpad-empty"></span><button class="dpad-btn" data-dir="down">\u25BC</button><span class="dpad-empty"></span></div>'
    +'</div> <button class="btn" id="g2048Restart">重开</button>';
  var btns=$("gameControls").getElementsByClassName("dpad-btn");
  for(var i=0;i<btns.length;i++){
    btns[i].onclick=function(){ move(this.getAttribute("data-dir")); };
  }
  $("g2048Restart").onclick=function(){ startGame("2048"); };
  init();
  render();
};

/* ==================== 5. 贪吃蛇 ==================== */
GAME_INITS.snake = function(){
  var CW=20, CH=20, CELL=22;
  var snake, dir, nextDir, food, score, timer, over;

  function init(){
    snake=[{x:10,y:10},{x:9,y:10},{x:8,y:10}];
    dir={x:1,y:0}; nextDir={x:1,y:0};
    score=0; over=false;
    placeFood();
    $("gameScore").textContent="分数:"+score+" 最高:"+getHigh("snake");
  }

  function placeFood(){
    while(true){
      var fx=Math.floor(Math.random()*CW), fy=Math.floor(Math.random()*CH);
      var ok=true;
      for(var i=0;i<snake.length;i++) if(snake[i].x===fx&&snake[i].y===fy){ ok=false; break; }
      if(ok){ food={x:fx,y:fy}; return; }
    }
  }

  function render(){
    var html='<canvas id="snakeCanvas" width="'+(CW*CELL)+'" height="'+(CH*CELL)+'" style="border:2px solid #000;"></canvas>';
    $("gameBody").innerHTML=html;
    var canvas=$("snakeCanvas");
    var ctx=canvas.getContext("2d");
    ctx.fillStyle="#fff"; ctx.fillRect(0,0,CW*CELL,CH*CELL);
    // 食物
    ctx.fillStyle="#000";
    ctx.beginPath(); ctx.arc(food.x*CELL+CELL/2,food.y*CELL+CELL/2,CELL/2-2,0,Math.PI*2); ctx.fill();
    // 蛇
    for(var i=0;i<snake.length;i++){
      ctx.fillStyle = i===0?"#000":"#333";
      ctx.fillRect(snake[i].x*CELL+1, snake[i].y*CELL+1, CELL-2, CELL-2);
    }
  }

  function tick(){
    if(over) return;
    dir=nextDir;
    var head={x:snake[0].x+dir.x, y:snake[0].y+dir.y};
    if(head.x<0||head.x>=CW||head.y<0||head.y>=CH){ gameOver(); return; }
    for(var i=0;i<snake.length;i++) if(snake[i].x===head.x&&snake[i].y===head.y){ gameOver(); return; }
    snake.unshift(head);
    if(head.x===food.x&&head.y===food.y){
      score+=10;
      $("gameScore").textContent="分数:"+score+" 最高:"+getHigh("snake");
      placeFood();
    } else {
      snake.pop();
    }
    render();
  }

  function gameOver(){
    over=true;
    clearInterval(timer);
    showModal("游戏结束","撞到了！分数:"+score,"再来一局",function(){ startGame("snake"); });
  }

  function setDir(d){
    if(d==='up'&&dir.y!==1) nextDir={x:0,y:-1};
    else if(d==='down'&&dir.y!==-1) nextDir={x:0,y:1};
    else if(d==='left'&&dir.x!==1) nextDir={x:-1,y:0};
    else if(d==='right'&&dir.x!==-1) nextDir={x:1,y:0};
  }

  $("gameControls").innerHTML = '<div class="dpad">'
    +'<div class="dpad-row"><span class="dpad-empty"></span><button class="dpad-btn" data-dir="up">\u25B2</button><span class="dpad-empty"></span></div>'
    +'<div class="dpad-row"><button class="dpad-btn" data-dir="left">\u25C0</button><span class="dpad-empty"></span><button class="dpad-btn" data-dir="right">\u25B6</button></div>'
    +'<div class="dpad-row"><span class="dpad-empty"></span><button class="dpad-btn" data-dir="down">\u25BC</button><span class="dpad-empty"></span></div>'
    +'</div>';
  var btns=$("gameControls").getElementsByClassName("dpad-btn");
  for(var i=0;i<btns.length;i++) btns[i].onclick=function(){ setDir(this.getAttribute("data-dir")); };

  init();
  render();
  timer=setInterval(tick, 500);
  GAME_CLEANUPS.snake = function(){ clearInterval(timer); };
};

/* ==================== 6. 扫雷 ==================== */
GAME_INITS.minesweeper = function(){
  var R=9, C=9, MINES=10;
  var board=[], revealed=[], flagged=[], over=false, firstClick=true, flagMode=false;

  function init(){
    board=[]; revealed=[]; flagged=[]; flagMode=false;
    for(var r=0;r<R;r++){ board[r]=[]; revealed[r]=[]; flagged[r]=[]; for(var c=0;c<C;c++){ board[r][c]=0; revealed[r][c]=false; flagged[r][c]=false; } }
    over=false; firstClick=true;
  }

  function placeMines(safeR,safeC){
    var placed=0;
    while(placed<MINES){
      var r=Math.floor(Math.random()*R), c=Math.floor(Math.random()*C);
      if(board[r][c]===-1) continue;
      if(Math.abs(r-safeR)<=1&&Math.abs(c-safeC)<=1) continue;
      board[r][c]=-1; placed++;
    }
    for(var r=0;r<R;r++) for(var c=0;c<C;c++){
      if(board[r][c]===-1) continue;
      var count=0;
      for(var dr=-1;dr<=1;dr++) for(var dc=-1;dc<=1;dc++){
        var nr=r+dr,nc=c+dc;
        if(nr>=0&&nr<R&&nc>=0&&nc<C&&board[nr][nc]===-1) count++;
      }
      board[r][c]=count;
    }
  }

  function render(){
    var html='<div class="board" style="font-size:0;">';
    for(var r=0;r<R;r++){
      html+='<div class="board-row">';
      for(var c=0;c<C;c++){
        var text='', bg='#ccc', color='#000';
        if(revealed[r][c]){
          bg='#fff';
          if(board[r][c]===-1){ text='X'; bg='#000'; }
          else if(board[r][c]>0){ text=board[r][c]; }
        } else if(flagged[r][c]){
          text='\u2691';
        }
        html+='<div class="cell" data-r="'+r+'" data-c="'+c+'" style="width:46px;height:46px;font-size:22px;line-height:42px;background:'+bg+';border:1px solid #666;color:'+color+';">'+text+'</div>';
      }
      html+='</div>';
    }
    html+='</div>';
    var unrevealed=0;
    for(var r=0;r<R;r++) for(var c=0;c<C;c++) if(!revealed[r][c]) unrevealed++;
    $("gameScore").textContent="剩余:"+unrevealed;
    $("gameBody").innerHTML=html;
    var cells=$("gameBody").getElementsByClassName("cell");
    for(var i=0;i<cells.length;i++){
      cells[i].onclick=function(){
        if(over) return;
        var r=parseInt(this.getAttribute("data-r")), c=parseInt(this.getAttribute("data-c"));
        if(revealed[r][c]) return;
        if(flagMode){
          flagged[r][c]=!flagged[r][c];
          render();
        } else {
          if(firstClick){ placeMines(r,c); firstClick=false; }
          reveal(r,c);
          render();
          checkWin();
        }
      };
    }
  }

  function reveal(r,c){
    if(r<0||r>=R||c<0||c>=C||revealed[r][c]||flagged[r][c]) return;
    revealed[r][c]=true;
    if(board[r][c]===-1){
      // 踩雷，显示所有雷
      over=true;
      for(var rr=0;rr<R;rr++) for(var cc=0;cc<C;cc++) if(board[rr][cc]===-1) revealed[rr][cc]=true;
      setTimeout(function(){ showModal("游戏结束","踩到地雷了！","再来一局",function(){startGame("minesweeper");}); },100);
      return;
    }
    if(board[r][c]===0){
      for(var dr=-1;dr<=1;dr++) for(var dc=-1;dc<=1;dc++) reveal(r+dr,c+dc);
    }
  }

  function checkWin(){
    if(over) return;
    for(var r=0;r<R;r++) for(var c=0;c<C;c++){
      if(board[r][c]!==-1 && !revealed[r][c]) return;
    }
    over=true;
    setTimeout(function(){ showModal("恭喜！","排除了所有地雷！","再来一局",function(){startGame("minesweeper");}); },100);
  }

  $("gameControls").innerHTML='<button class="btn" id="msFlag">插旗模式</button><button class="btn" id="msRestart">重开</button>';
  $("msFlag").onclick=function(){ flagMode=!flagMode; this.className = flagMode?"btn active":"btn"; this.textContent = flagMode?"插旗中(点击插旗)":"插旗模式"; };
  $("msRestart").onclick=function(){ startGame("minesweeper"); };
  init();
  render();
};

/* ==================== 7. 数独 ==================== */
GAME_INITS.sudoku = function(){
  var N=9;
  var solution=[], puzzle=[], userInput=[], selected=null, over=false;

  function generate(){
    // 用一个固定的有效解，然后挖空
    solution = [
      [5,3,4,6,7,8,9,1,2],[6,7,2,1,9,5,3,4,8],[1,9,8,3,4,2,5,6,7],
      [8,5,9,7,6,1,4,2,3],[4,2,6,8,5,3,7,9,1],[7,1,3,9,2,4,8,5,6],
      [9,6,1,5,3,7,2,8,4],[2,8,7,4,1,9,6,3,5],[3,4,5,2,8,6,1,7,9]
    ];
    // 随机交换行/列/数字
    var nums=[1,2,3,4,5,6,7,8,9]; shuffle(nums);
    var map={}; for(var i=0;i<9;i++) map[i+1]=nums[i];
    for(var r=0;r<9;r++) for(var c=0;c<9;c++) solution[r][c]=map[solution[r][c]];
    // 挖空
    puzzle=[]; userInput=[];
    for(var r=0;r<9;r++){ puzzle[r]=[]; userInput[r]=[]; for(var c=0;c<9;c++){ puzzle[r][c]=solution[r][c]; userInput[r][c]=0; } }
    var positions=[];
    for(var r=0;r<9;r++) for(var c=0;c<9;c++) positions.push([r,c]);
    shuffle(positions);
    var holes=45;
    for(var i=0;i<holes;i++){ puzzle[positions[i][0]][positions[i][1]]=0; }
  }

  function render(){
    var html='<div class="board" style="font-size:0;">';
    for(var r=0;r<9;r++){
      html+='<div class="board-row">';
      for(var c=0;c<9;c++){
        var v = puzzle[r][c]!==0 ? puzzle[r][c] : (userInput[r][c]||'');
        var isFixed = puzzle[r][c]!==0;
        var isSel = selected && selected[0]===r && selected[1]===c;
        var bg = isSel?'#000':'#fff';
        var color = isSel?'#fff':(isFixed?'#000':'#666');
        var bw = (c%3===2&&c!==8)?'3px solid #000':'1px solid #999';
        var bh = (r%3===2&&r!==8)?'3px solid #000':'1px solid #999';
        html+='<div class="cell" data-r="'+r+'" data-c="'+c+'" style="width:48px;height:48px;font-size:26px;line-height:44px;background:'+bg+';color:'+color+';border-right:'+bw+';border-bottom:'+bh+';">'+v+'</div>';
      }
      html+='</div>';
    }
    html+='</div>';
    $("gameBody").innerHTML=html;
    var cells=$("gameBody").getElementsByClassName("cell");
    for(var i=0;i<cells.length;i++){
      cells[i].onclick=function(){
        if(over) return;
        var r=parseInt(this.getAttribute("data-r")), c=parseInt(this.getAttribute("data-c"));
        if(puzzle[r][c]!==0) return;
        selected=[r,c];
        render();
      };
    }
  }

  function inputNum(n){
    if(!selected || over) return;
    var r=selected[0], c=selected[1];
    if(puzzle[r][c]!==0) return;
    userInput[r][c] = n;
    render();
    checkWin();
  }

  function checkWin(){
    for(var r=0;r<9;r++) for(var c=0;c<9;c++){
      var v = puzzle[r][c]!==0 ? puzzle[r][c] : userInput[r][c];
      if(v!==solution[r][c]) return;
    }
    over=true;
    setTimeout(function(){ showModal("恭喜！","数独完成！","再来一局",function(){startGame("sudoku");}); },100);
  }

  $("gameControls").innerHTML='<button class="btn" data-n="1">1</button><button class="btn" data-n="2">2</button><button class="btn" data-n="3">3</button><button class="btn" data-n="4">4</button><button class="btn" data-n="5">5</button><button class="btn" data-n="6">6</button><button class="btn" data-n="7">7</button><button class="btn" data-n="8">8</button><button class="btn" data-n="9">9</button><button class="btn" data-n="0">清除</button><button class="btn" id="sdRestart">重开</button>';
  var numBtns=$("gameControls").getElementsByClassName("btn");
  for(var i=0;i<numBtns.length;i++){
    if(numBtns[i].getAttribute("data-n")){
      numBtns[i].onclick=function(){ inputNum(parseInt(this.getAttribute("data-n"))); };
    }
  }
  $("sdRestart").onclick=function(){ startGame("sudoku"); };
  generate();
  render();
};

/* ==================== 8. 俄罗斯方块 ==================== */
GAME_INITS.tetris = function(){
  var COLS=10, ROWS=18, CELL=26;
  var grid, current, pos, score, lines, timer, over, dropInterval;

  var SHAPES = {
    I:[[1,1,1,1]], O:[[1,1],[1,1]], T:[[0,1,0],[1,1,1]],
    S:[[0,1,1],[1,1,0]], Z:[[1,1,0],[0,1,1]], J:[[1,0,0],[1,1,1]], L:[[0,0,1],[1,1,1]]
  };

  function init(){
    grid=[];
    for(var r=0;r<ROWS;r++){ grid[r]=[]; for(var c=0;c<COLS;c++) grid[r][c]=0; }
    score=0; lines=0; over=false; dropInterval=600;
    spawn();
    $("gameScore").textContent="分数:"+score+" 最高:"+getHigh("snake");
  }

  function spawn(){
    var keys=[];
    for(var k in SHAPES) keys.push(k);
    var shape=SHAPES[keys[Math.floor(Math.random()*keys.length)]];
    current=[];
    for(var r=0;r<shape.length;r++){ current[r]=[]; for(var c=0;c<shape[r].length;c++) current[r][c]=shape[r][c]; }
    pos={x:Math.floor((COLS-current[0].length)/2), y:0};
    if(collides(pos.x,pos.y,current)){
      over=true;
      clearInterval(timer);
      showModal("游戏结束","分数:"+score,"再来一局",function(){startGame("tetris");});
    }
  }

  function collides(px,py,shape){
    for(var r=0;r<shape.length;r++) for(var c=0;c<shape[r].length;c++){
      if(!shape[r][c]) continue;
      var nx=px+c, ny=py+r;
      if(nx<0||nx>=COLS||ny>=ROWS) return true;
      if(ny>=0 && grid[ny][nx]) return true;
    }
    return false;
  }

  function merge(){
    for(var r=0;r<current.length;r++) for(var c=0;c<current[r].length;c++){
      if(current[r][c] && pos.y+r>=0) grid[pos.y+r][pos.x+c]=1;
    }
  }

  function clearLines(){
    var cleared=0;
    for(var r=ROWS-1;r>=0;r--){
      var full=true;
      for(var c=0;c<COLS;c++) if(!grid[r][c]){ full=false; break; }
      if(full){
        grid.splice(r,1);
        var newRow=[]; for(var cc=0;cc<COLS;cc++) newRow.push(0);
        grid.unshift(newRow);
        cleared++;
        r++;
      }
    }
    if(cleared>0){
      var pts=[0,100,300,500,800];
      score += pts[cleared];
      lines += cleared;
      $("gameScore").textContent="分数:"+score+" 最高:"+getHigh("snake");
      if(lines%10===0 && dropInterval>200) dropInterval-=50;
    }
  }

  function render(){
    var html='<canvas id="tetrisCanvas" width="'+(COLS*CELL)+'" height="'+(ROWS*CELL)+'" style="border:2px solid #000;"></canvas>';
    $("gameBody").innerHTML=html;
    var canvas=$("tetrisCanvas");
    var ctx=canvas.getContext("2d");
    ctx.fillStyle="#fff"; ctx.fillRect(0,0,COLS*CELL,ROWS*CELL);
    // 已固定
    ctx.fillStyle="#000";
    for(var r=0;r<ROWS;r++) for(var c=0;c<COLS;c++) if(grid[r][c]) ctx.fillRect(c*CELL+1,r*CELL+1,CELL-2,CELL-2);
    // 当前方块
    ctx.fillStyle="#333";
    for(var r=0;r<current.length;r++) for(var c=0;c<current[r].length;c++){
      if(current[r][c]) ctx.fillRect((pos.x+c)*CELL+1,(pos.y+r)*CELL+1,CELL-2,CELL-2);
    }
  }

  function tick(){
    if(over) return;
    if(!collides(pos.x,pos.y+1,current)){
      pos.y++;
    } else {
      merge();
      clearLines();
      spawn();
    }
    render();
  }

  function move(dx){ if(!collides(pos.x+dx,pos.y,current)){ pos.x+=dx; render(); } }
  function rotate(){
    var rows=current.length, cols=current[0].length;
    var rotated=[];
    for(var c=0;c<cols;c++){ rotated[c]=[]; for(var r=rows-1;r>=0;r--) rotated[c][rows-1-r]=current[r][c]; }
    if(!collides(pos.x,pos.y,rotated)){ current=rotated; render(); }
  }
  function hardDrop(){
    while(!collides(pos.x,pos.y+1,current)) pos.y++;
    tick();
  }

  $("gameControls").innerHTML = '<button class="btn" id="teLeft">\u25C0</button><button class="btn" id="teRotate">旋转</button><button class="btn" id="teRight">\u25B6</button><button class="btn" id="teDown">\u25BC</button><button class="btn" id="teDrop">直落</button>';
  $("teLeft").onclick=function(){ move(-1); };
  $("teRight").onclick=function(){ move(1); };
  $("teRotate").onclick=function(){ rotate(); };
  $("teDown").onclick=function(){ tick(); };
  $("teDrop").onclick=function(){ hardDrop(); };

  init();
  render();
  timer=setInterval(tick, 600);
  GAME_CLEANUPS.tetris = function(){ clearInterval(timer); };
};

/* ==================== 9. 推箱子 ==================== */
GAME_INITS.sokoban = function(){
  var LEVELS = [
    [
      "########",
      "#      #",
      "#  $   #",
      "#  .   #",
      "#  @   #",
      "#      #",
      "########"
    ],
    [
      "  #####  ",
      "###   ###",
      "#  $ $  #",
      "# . . . #",
      "#   @   #",
      "#########"
    ],
    [
      "########",
      "#   .  #",
      "# $$$  #",
      "# .@.  #",
      "# $$$  #",
      "#   .  #",
      "########"
    ],
    [
      "########",
      "#      #",
      "# $ .  #",
      "#  @   #",
      "#      #",
      "########"
    ],
    [
      "########",
      "# .  . #",
      "#  $$  #",
      "#  @   #",
      "########"
    ],
    [
      "  ######",
      "###    #",
      "# $ $  #",
      "# . .  #",
      "#  @   #",
      "########"
    ],
    [
      "#########",
      "#   .   #",
      "# $ $ $ #",
      "#   .   #",
      "# . @ . #",
      "#########"
    ],
    [
      "  #######",
      "###     #",
      "# $ $ $ #",
      "# # # # #",
      "# . . . #",
      "#   @   #",
      "#########"
    ],
    [
      "##########",
      "#        #",
      "#  $$$$  #",
      "#  .  .  #",
      "#  .  .  #",
      "#   @    #",
      "##########"
    ],
    [
      "  #########",
      "###       #",
      "#  $ $ $  #",
      "#  # # #  #",
      "#  . . .  #",
      "#    @    #",
      "###########"
    ]
  ];
  var levelIdx=0, grid, player, boxes, targets, moves;

  function loadLevel(idx){
    var raw=LEVELS[idx];
    grid=[]; boxes=[]; targets=[]; moves=0;
    for(var r=0;r<raw.length;r++){
      grid[r]=[];
      for(var c=0;c<raw[r].length;c++){
        var ch=raw[r][c];
        grid[r][c] = ch==='#'?'#':' ';
        if(ch==='@') player={x:c,y:r};
        if(ch==='$') boxes.push({x:c,y:r});
        if(ch==='.') targets.push({x:c,y:r});
        if(ch==='*'){ boxes.push({x:c,y:r}); targets.push({x:c,y:r}); }
      }
    }
    $("gameScore").textContent="步数:"+moves+" 最佳:"+getHigh("memory");
  }

  function render(){
    var html='<div class="board" style="font-size:0;background:#fff;">';
    var maxR=grid.length, maxC=0;
    for(var r=0;r<maxR;r++) maxC=Math.max(maxC,grid[r].length);
    for(var r=0;r<maxR;r++){
      html+='<div class="board-row">';
      for(var c=0;c<maxC;c++){
        var ch=grid[r]&&grid[r][c]?grid[r][c]:' ';
        var bg='#fff', text='';
        if(ch==='#'){ bg='#000'; }
        // 目标点
        for(var t=0;t<targets.length;t++) if(targets[t].x===c&&targets[t].y===r){ text='\u00B7'; }
        // 箱子
        for(var b=0;b<boxes.length;b++) if(boxes[b].x===c&&boxes[b].y===r){
          var onTarget=false;
          for(var t=0;t<targets.length;t++) if(targets[t].x===c&&targets[t].y===r) onTarget=true;
          text = onTarget?'\u25A0':'\u25A1';
        }
        // 玩家
        if(player.x===c&&player.y===r){ text='\u25CF'; }
        html+='<div class="cell" style="width:44px;height:44px;font-size:24px;line-height:40px;background:'+bg+';color:'+(bg==='#000'?'#fff':'#000')+';border:1px solid #ccc;">'+text+'</div>';
      }
      html+='</div>';
    }
    html+='</div>';
    $("gameBody").innerHTML=html;
  }

  function move(dx,dy){
    var nx=player.x+dx, ny=player.y+dy;
    if(grid[ny]&&grid[ny][nx]==='#') return;
    // 检查是否推箱子
    for(var i=0;i<boxes.length;i++){
      if(boxes[i].x===nx&&boxes[i].y===ny){
        var bx=nx+dx, by=ny+dy;
        if(grid[by]&&grid[by][bx]==='#') return;
        for(var j=0;j<boxes.length;j++) if(boxes[j].x===bx&&boxes[j].y===by) return;
        boxes[i].x=bx; boxes[i].y=by;
        break;
      }
    }
    player.x=nx; player.y=ny;
    moves++;
    $("gameScore").textContent="步数:"+moves+" 最佳:"+getHigh("memory");
    render();
    checkWin();
  }

  function checkWin(){
    for(var i=0;i<boxes.length;i++){
      var onTarget=false;
      for(var t=0;t<targets.length;t++) if(targets[t].x===boxes[i].x&&targets[t].y===boxes[i].y) onTarget=true;
      if(!onTarget) return;
    }
    if(levelIdx<LEVELS.length-1){
      showModal("过关！","用了"+moves+"步","下一关",function(){ levelIdx++; loadLevel(levelIdx); render(); });
    } else {
      showModal("全部通关！","恭喜完成所有关卡！","再来一次",function(){ levelIdx=0; loadLevel(0); render(); });
    }
  }

  $("gameControls").innerHTML = '<div class="dpad">'
    +'<div class="dpad-row"><span class="dpad-empty"></span><button class="dpad-btn" data-dx="0" data-dy="-1">\u25B2</button><span class="dpad-empty"></span></div>'
    +'<div class="dpad-row"><button class="dpad-btn" data-dx="-1" data-dy="0">\u25C0</button><span class="dpad-empty"></span><button class="dpad-btn" data-dx="1" data-dy="0">\u25B6</button></div>'
    +'<div class="dpad-row"><span class="dpad-empty"></span><button class="dpad-btn" data-dx="0" data-dy="1">\u25BC</button><span class="dpad-empty"></span></div>'
    +'</div> <button class="btn" id="skReset">重置</button><button class="btn" id="skNext">下一关</button>';
  var dbtns=$("gameControls").getElementsByClassName("dpad-btn");
  for(var i=0;i<dbtns.length;i++){
    dbtns[i].onclick=function(){ move(parseInt(this.getAttribute("data-dx")),parseInt(this.getAttribute("data-dy"))); };
  }
  $("skReset").onclick=function(){ loadLevel(levelIdx); render(); };
  $("skNext").onclick=function(){ levelIdx=(levelIdx+1)%LEVELS.length; loadLevel(levelIdx); render(); };
  loadLevel(0);
  render();
};

/* ==================== 10. 打砖块 ==================== */
GAME_INITS.breakout = function(){
  var W=400, H=440, PADDLE_W=80, PADDLE_H=10, BALL_R=6, BRICK_ROWS=5, BRICK_COLS=8;
  var canvas, ctx, paddleX, ball, bricks, score, lives, timer, over, running;

  function init(){
    paddleX=W/2-PADDLE_W/2;
    ball={x:W/2,y:H-30,dx:2,dy:-2};
    bricks=[];
    for(var r=0;r<BRICK_ROWS;r++){
      bricks[r]=[];
      for(var c=0;c<BRICK_COLS;c++) bricks[r][c]=1;
    }
    score=0; lives=3; over=false; running=true;
    $("gameScore").textContent="分数:"+score+" 生命:"+lives+" 最高:"+getHigh("breakout");
  }

  function render(){
    var html='<canvas id="breakoutCanvas" width="'+W+'" height="'+H+'" style="border:2px solid #000;"></canvas>';
    $("gameBody").innerHTML=html;
    canvas=$("breakoutCanvas");
    ctx=canvas.getContext("2d");
  }

  function draw(){
    ctx.fillStyle="#fff"; ctx.fillRect(0,0,W,H);
    // 砖块
    var bw=W/BRICK_COLS, bh=16;
    for(var r=0;r<BRICK_ROWS;r++) for(var c=0;c<BRICK_COLS;c++){
      if(bricks[r][c]){
        ctx.fillStyle = r%2===0?"#000":"#666";
        ctx.fillRect(c*bw+1, r*bh+20+1, bw-2, bh-2);
      }
    }
    // 挡板
    ctx.fillStyle="#000";
    ctx.fillRect(paddleX, H-PADDLE_H-10, PADDLE_W, PADDLE_H);
    // 球
    ctx.beginPath(); ctx.arc(ball.x,ball.y,BALL_R,0,Math.PI*2); ctx.fill();
  }

  function tick(){
    if(!running||over) return;
    ball.x+=ball.dx; ball.y+=ball.dy;
    // 墙壁
    if(ball.x<BALL_R||ball.x>W-BALL_R) ball.dx=-ball.dx;
    if(ball.y<BALL_R) ball.dy=-ball.dy;
    // 挡板
    if(ball.y>H-PADDLE_H-10-BALL_R && ball.y<H-10 && ball.x>paddleX && ball.x<paddleX+PADDLE_W){
      ball.dy=-Math.abs(ball.dy);
      var hitPos=(ball.x-paddleX)/PADDLE_W;
      ball.dx = (hitPos-0.5)*4;
    }
    // 砖块
    var bw=W/BRICK_COLS, bh=16;
    for(var r=0;r<BRICK_ROWS;r++) for(var c=0;c<BRICK_COLS;c++){
      if(bricks[r][c]){
        var bx=c*bw, by=r*bh+20;
        if(ball.x+BALL_R>bx && ball.x-BALL_R<bx+bw && ball.y+BALL_R>by && ball.y-BALL_R<by+bh){
          bricks[r][c]=0;
          ball.dy=-ball.dy;
          score+=10;
          $("gameScore").textContent="分数:"+score+" 生命:"+lives+" 最高:"+getHigh("breakout");
          // 检查胜利
          var remain=0;
          for(var rr=0;rr<BRICK_ROWS;rr++) for(var cc=0;cc<BRICK_COLS;cc++) if(bricks[rr][cc]) remain++;
          if(remain===0){ over=true; clearInterval(timer); showModal("恭喜！","打碎了所有砖块！分数:"+score,"再来一局",function(){startGame("breakout");}); }
        }
      }
    }
    // 掉落
    if(ball.y>H){
      lives--;
      $("gameScore").textContent="分数:"+score+" 生命:"+lives+" 最高:"+getHigh("breakout");
      if(lives<=0){
        over=true; clearInterval(timer);
        showModal("游戏结束","分数:"+score,"再来一局",function(){startGame("breakout");});
      } else {
        ball={x:W/2,y:H-30,dx:2,dy:-2};
        paddleX=W/2-PADDLE_W/2;
      }
    }
    draw();
  }

  $("gameControls").innerHTML = '<button class="btn" id="boLeft">\u25C0 左</button><button class="btn" id="boRight">右 \u25B6</button><button class="btn" id="boPause">暂停</button><button class="btn" id="boRestart">重开</button>';
  $("boLeft").onclick=function(){ paddleX=Math.max(0,paddleX-20); draw(); };
  $("boRight").onclick=function(){ paddleX=Math.min(W-PADDLE_W,paddleX+20); draw(); };
  $("boPause").onclick=function(){ running=!running; this.textContent=running?"暂停":"继续"; if(running){ timer=setInterval(tick,30);} else { clearInterval(timer);} };
  $("boRestart").onclick=function(){ startGame("breakout"); };

  init();
  render();
  draw();
  timer=setInterval(tick, 30);
  GAME_CLEANUPS.breakout = function(){ clearInterval(timer); };
};

/* ==================== 11. 记忆翻牌 ==================== */
GAME_INITS.memory = function(){
  var SYMBOLS=["\u2600","\u2601","\u2602","\u2603","\u2604","\u2605","\u2606","\u260E"];
  var cards=[], flipped=[], matched=[], firstPick=null, moves=0, lock=false;

  function init(){
    cards=[];
    for(var i=0;i<SYMBOLS.length;i++){ cards.push(SYMBOLS[i]); cards.push(SYMBOLS[i]); }
    shuffle(cards);
    flipped=[]; matched=[]; firstPick=null; moves=0; lock=false;
    for(var i=0;i<cards.length;i++){ flipped[i]=false; matched[i]=false; }
    $("gameScore").textContent="步数:"+moves+" 最佳:"+getHigh("memory");
  }

  function render(){
    var html='<div style="display:inline-block;">';
    for(var r=0;r<4;r++){
      html+='<div style="display:block;">';
      for(var c=0;c<4;c++){
        var idx=r*4+c;
        var show = flipped[idx]||matched[idx];
        var bg = matched[idx]?'#ccc':'#000';
        var color = matched[idx]?'#666':'#fff';
        var text = show?cards[idx]:'?';
        html+='<div class="cell mem-card" data-idx="'+idx+'" style="width:82px;height:82px;font-size:40px;line-height:78px;background:'+bg+';color:'+color+';border:2px solid #000;display:inline-block;vertical-align:middle;">'+text+'</div>';
      }
      html+='</div>';
    }
    html+='</div>';
    $("gameBody").innerHTML=html;
    var cards_el=$("gameBody").getElementsByClassName("mem-card");
    for(var i=0;i<cards_el.length;i++){
      cards_el[i].onclick=function(){
        if(lock) return;
        var idx=parseInt(this.getAttribute("data-idx"));
        if(flipped[idx]||matched[idx]) return;
        flipped[idx]=true;
        render();
        if(firstPick===null){
          firstPick=idx;
        } else {
          moves++;
          $("gameScore").textContent="步数:"+moves+" 最佳:"+getHigh("memory");
          if(cards[firstPick]===cards[idx]){
            matched[firstPick]=true; matched[idx]=true;
            firstPick=null;
            render();
            checkWin();
          } else {
            lock=true;
            var a=firstPick, b=idx;
            setTimeout(function(){ flipped[a]=false; flipped[b]=false; firstPick=null; lock=false; render(); },600);
          }
        }
      };
    }
  }

  function checkWin(){
    for(var i=0;i<matched.length;i++) if(!matched[i]) return;
    setTimeout(function(){ showModal("恭喜！","用了"+moves+"步完成配对！","再来一局",function(){startGame("memory");}); },300);
  }

  $("gameControls").innerHTML='<button class="btn" id="memRestart">重开</button>';
  $("memRestart").onclick=function(){ startGame("memory"); };
  init();
  render();
};

/* ==================== 12. 华容道（数字拼图） ==================== */
GAME_INITS.puzzle = function(){
  var N=4, tiles=[], empty, moves=0;

  function init(){
    tiles=[];
    for(var i=1;i<N*N;i++) tiles.push(i);
    tiles.push(0); // 0=空格
    // 随机打乱（保证可解）
    do {
      shuffle(tiles);
    } while(!isSolvable());
    empty = tiles.indexOf(0);
    moves=0;
    $("gameScore").textContent="步数:"+moves+" 最佳:"+getHigh("memory");
  }

  function isSolvable(){
    var inv=0;
    for(var i=0;i<tiles.length;i++) for(var j=i+1;j<tiles.length;j++){
      if(tiles[i]&&tiles[j]&&tiles[i]>tiles[j]) inv++;
    }
    var emptyRow = Math.floor(tiles.indexOf(0)/N);
    if(N%2===1) return inv%2===0;
    return (inv+emptyRow)%2===1;
  }

  function render(){
    var html='<div class="board" style="font-size:0;">';
    for(var r=0;r<N;r++){
      html+='<div class="board-row">';
      for(var c=0;c<N;c++){
        var idx=r*N+c;
        var v=tiles[idx];
        var bg = v===0?'#fff':'#000';
        var color = v===0?'#fff':'#fff';
        html+='<div class="cell pz-cell" data-idx="'+idx+'" style="width:84px;height:84px;font-size:40px;line-height:80px;background:'+bg+';color:'+color+';border:2px solid #000;">'+(v||'')+'</div>';
      }
      html+='</div>';
    }
    html+='</div>';
    $("gameBody").innerHTML=html;
    var cells=$("gameBody").getElementsByClassName("pz-cell");
    for(var i=0;i<cells.length;i++){
      cells[i].onclick=function(){
        var idx=parseInt(this.getAttribute("data-idx"));
        tryMove(idx);
      };
    }
  }

  function tryMove(idx){
    var r=Math.floor(idx/N), c=idx%N;
    var er=Math.floor(empty/N), ec=empty%N;
    if((Math.abs(r-er)===1&&c===ec)||(Math.abs(c-ec)===1&&r===er)){
      tiles[empty]=tiles[idx];
      tiles[idx]=0;
      empty=idx;
      moves++;
      $("gameScore").textContent="步数:"+moves+" 最佳:"+getHigh("memory");
      render();
      checkWin();
    }
  }

  function checkWin(){
    for(var i=0;i<N*N-1;i++) if(tiles[i]!==i+1) return;
    setTimeout(function(){ showModal("恭喜！","用了"+moves+"步完成拼图！","再来一局",function(){startGame("puzzle");}); },200);
  }

  $("gameControls").innerHTML='<button class="btn" id="pzRestart">重开</button>';
  $("pzRestart").onclick=function(){ startGame("puzzle"); };
  init();
  render();
};

/* ==================== 13. 电子宠物（完整版v2） ==================== */
GAME_INITS.pet = function(){
  var W=380,H=220;
  var pet={hunger:80,happy:80,clean:80,energy:80,health:100,weight:5,age:0,coins:100,x:130,y:0,dir:1,walkFrame:0,sleeping:false,sick:false,dead:false,action:"idle",actionTimer:0,jumpH:0,loveTimer:0};
  var timer,tickCount=0,blinkCount=0,blinking=false,panel="main",clouds=[{x:50,y:20},{x:200,y:35}];

  var EGG=["...XXXX...","..XXXXXX..",".XXXXXXXX.",".XXXXXXXX.","XXXXXXXXXX","XXXXXXXXXX",".XXXXXXXX.",".XXXXXXXX.","..XXXXXX..","...XXXX..."];
  var BABY=["....XXXXXXXX....","..XXXXXXXXXXXX..",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.",".XX..XXXXXX..XX.",".XX...X..X...XX.",".XX..XXXXXX..XX.",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.",".XXXXXX..XXXXXX.",".XXXXXXXXXXXXXX.","..XXXXXXXXXXXX..","...XXXXXXXXXX...","....XX....XX....","....XX....XX....","...XXX....XXX..."];
  var BABY_B=["....XXXXXXXX....","..XXXXXXXXXXXX..",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.",".XX..XXXX..XX...",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.",".XXXXXX..XXXXXX.",".XXXXXXXXXXXXXX.","..XXXXXXXXXXXX..","...XXXXXXXXXX...","....XX....XX....","....XX....XX....","...XXX....XXX..."];
  var TEEN=["..XX........XX..",".XXXX......XXXX.",".XXXX......XXXX.","..XXXXXXXXXXXX..",".XXXXXXXXXXXXXX.",".XX..XXXXXXXX..X.",".XX...X......X.X.",".XX..XXXXXXXX..X.",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.",".XXXXXXX..XXXXXXX",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.","..XXXXXXXXXXXX..",".XX..XXXXXX..XX.",".XX..XXXXXX..XX.","...XX......XX...","...XX......XX..."];
  var TEEN_B=["..XX........XX..",".XXXX......XXXX.",".XXXX......XXXX.","..XXXXXXXXXXXX..",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.",".XX..XXXX..XX...",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.",".XXXXXXX..XXXXXXX",".XXXXXXXXXXXXXX.",".XXXXXXXXXXXXXX.","..XXXXXXXXXXXX..",".XX..XXXXXX..XX.",".XX..XXXXXX..XX.","...XX......XX...","...XX......XX..."];
  var ADULT=["...XX........XX...","..XXXX......XXXX..","..XXXX......XXXX..","..XXXXXXXXXXXXXX..",".XXXXXXXXXXXXXXXX.",".XX..XXXXXXXX..XX.",".XX...X......X..X.",".XX..XXXXXXXX..XX.",".XXXXXXXXXXXXXXXX.",".XXXXXXXXXXXXXXXX.",".XXXXXXXXXXXXXXXX.",".XXXXXXX..XXXXXXXXX",".XXXXXXXXXXXXXXXX.",".XXXXXXXXXXXXXXXX.","..XXXXXXXXXXXXXX..",".XX..XXXXXXXX..XX.",".XX..XXXXXXXX..XX.","...XX........XX...","...XX........XX...","..XXX......XXX...."];
  var ADULT_B=["...XX........XX...","..XXXX......XXXX..","..XXXX......XXXX..","..XXXXXXXXXXXXXX..",".XXXXXXXXXXXXXXXX.",".XXXXXXXXXXXXXXXX.",".XX..XXXX..XX.....",".XXXXXXXXXXXXXXXX.",".XXXXXXXXXXXXXXXX.",".XXXXXXXXXXXXXXXX.",".XXXXXXXXXXXXXXXX.",".XXXXXXX..XXXXXXXXX",".XXXXXXXXXXXXXXXX.",".XXXXXXXXXXXXXXXX.","..XXXXXXXXXXXXXX..",".XX..XXXXXXXX..XX.",".XX..XXXXXXXX..XX.","...XX........XX...","...XX........XX...","..XXX......XXX...."];
  var TREE=["....X....","...XXX...","..XXXXX..",".XXXXXXX.","XXXXXXXXX","...XXX...","...XXX...","...XXX..."];
  var FLOWER=["..X..","..X..","XXXXX","..X..","..X.."];

  var FOODS=[
    {name:"面包",hunger:15,price:5},
    {name:"苹果",hunger:10,happy:5,price:8},
    {name:"肉",hunger:30,price:15},
    {name:"蛋糕",hunger:10,happy:20,price:25},
    {name:"牛奶",hunger:5,health:10,price:10}
  ];
  var SHOPITEMS=[
    {name:"玩具球",happy:30,price:20},
    {name:"洗发水",clean:50,price:15},
    {name:"维生素",health:25,price:30},
    {name:"能量饮料",energy:40,price:20}
  ];

  function save(){try{pet.lastSave=Date.now();localStorage.setItem("kg_pet2",JSON.stringify(pet));}catch(e){}}
  function load(){
    try{
      var s=localStorage.getItem("kg_pet2");
      if(s){
        var d=JSON.parse(s);
        for(var k in d)pet[k]=d[k];
        if(d.lastSave){
          var off=Math.floor((Date.now()-d.lastSave)/200);
          if(off>0&&off<50000){
            var r=pet.sleeping?0.3:1;
            pet.hunger=clamp(pet.hunger-off*0.08*r);
            pet.happy=clamp(pet.happy-off*0.06*r);
            pet.clean=clamp(pet.clean-off*0.05*r);
            if(pet.sleeping)pet.energy=clamp(pet.energy+off*0.5);
            else pet.energy=clamp(pet.energy-off*0.03*r);
            pet.age+=Math.floor(off/100);
            pet.coins+=Math.floor(off/100)*10;
          }
        }
      }
    }catch(e){}
  }
  function clamp(v){return Math.max(0,Math.min(100,Math.round(v)));}
  function getStage(){return pet.age<3?0:pet.age<10?1:pet.age<25?2:3;}
  function stageName(){var s=["蛋","婴儿","少年","成年"];return s[getStage()];}
  function getSprite(){
    var st=getStage();
    if(st===0)return EGG;
    if(st===1)return blinking?BABY_B:BABY;
    if(st===2)return blinking?TEEN_B:TEEN;
    return blinking?ADULT_B:ADULT;
  }
  function pxSize(){var s=[4,3,3,3];return s[getStage()];}
  function mood(){
    if(pet.dead)return "已离开";
    if(pet.sick)return "生病了";
    if(pet.sleeping)return "睡觉中";
    if(pet.hunger<20)return "饿了";
    if(pet.energy<20)return "困了";
    if(pet.clean<20)return "脏了";
    if(pet.happy<30)return "不开心";
    if(pet.happy>70&&pet.health>70)return "很开心";
    return "一般";
  }

  function pickAction(){
    if(pet.sleeping||getStage()===0||pet.dead){pet.action="idle";pet.actionTimer=10;return;}
    var r=Math.random();
    if(r<0.25){pet.action="walk";pet.actionTimer=15+Math.floor(Math.random()*20);}
    else if(r<0.40){pet.action="jump";pet.actionTimer=10;pet.jumpH=0;}
    else if(r<0.55){pet.action="play";pet.actionTimer=10;}
    else if(r<0.62){pet.action="yawn";pet.actionTimer=6;}
    else if(r<0.75){pet.action="sit";pet.actionTimer=8+Math.floor(Math.random()*8);}
    else{pet.action="idle";pet.actionTimer=10+Math.floor(Math.random()*15);}
  }

  function feed(idx){
    var f=FOODS[idx];
    if(pet.coins<f.price){showModal("金币不足","需要"+f.price+"金币","确定");return;}
    pet.coins-=f.price;
    pet.hunger=clamp(pet.hunger+f.hunger);
    if(f.happy)pet.happy=clamp(pet.happy+f.happy);
    if(f.health)pet.health=clamp(pet.health+f.health);
    pet.weight+=1;
    pet.action="idle";pet.actionTimer=10;
    showModal("喂食","吃了"+f.name+"！","确定");
    showMain();save();
  }
  function playGame(type){
    if(pet.energy<10){showModal("太累了","体力不足，先睡觉吧","确定");return;}
    if(pet.sick){showModal("生病了","先看病吧","确定");return;}
    if(type==="catch"){
      pet.happy=clamp(pet.happy+15);pet.energy=clamp(pet.energy-12);pet.hunger=clamp(pet.hunger-8);pet.weight=Math.max(1,pet.weight-1);
      if(Math.random()<0.45){pet.coins+=10;showModal("接球！","太棒了！获得10金币","确定");}
      else showModal("接球！","玩得很开心","确定");
    }else{
      pet.happy=clamp(pet.happy+10);pet.energy=clamp(pet.energy-8);pet.hunger=clamp(pet.hunger-5);
      var r=Math.random();
      if(r<0.33){pet.coins+=12;showModal("猜拳","你赢了！获得12金币","确定");}
      else if(r<0.66)showModal("猜拳","平局","确定");
      else showModal("猜拳","你输了...","确定");
    }
    showMain();save();
  }
  function bathe(){
    if(pet.sleeping){showModal("睡觉中","睡醒再洗吧","确定");return;}
    pet.clean=clamp(pet.clean+45);pet.happy=clamp(pet.happy+5);pet.energy=clamp(pet.energy-5);
    pet.action="idle";pet.actionTimer=10;
    showModal("洗澡","洗得干干净净！","确定");updateUI();save();
  }
  function toggleSleep(){
    pet.sleeping=!pet.sleeping;
    pet.action="idle";pet.actionTimer=10;
    if(pet.sleeping)showModal("睡觉","晚安Zzz","确定");
    else showModal("起床","精神满满！","确定");
    updateUI();save();
  }
  function medicine(){
    if(!pet.sick&&pet.health>70){showModal("很健康","不需要吃药","确定");return;}
    if(pet.coins<15){showModal("金币不足","看病需要15金币","确定");return;}
    pet.coins-=15;
    pet.health=clamp(pet.health+35);
    pet.hunger=clamp(pet.hunger+15);
    pet.happy=clamp(pet.happy+15);
    pet.clean=clamp(pet.clean+15);
    pet.sick=false;
    pet.action="idle";pet.actionTimer=10;
    showModal("看病","吃了药，全面恢复！","确定");updateUI();save();
  }
  function walk(){
    if(pet.energy<15){showModal("太累了","体力不足","确定");return;}
    if(pet.sick){showModal("生病了","先看病吧","确定");return;}
    pet.happy=clamp(pet.happy+12);pet.health=clamp(pet.health+8);pet.energy=clamp(pet.energy-18);pet.hunger=clamp(pet.hunger-10);pet.clean=clamp(pet.clean-8);pet.weight=Math.max(1,pet.weight-1);
    pet.coins+=5;
    showModal("散步","外面真好玩！获得5金币","确定");
    updateUI();save();
  }
  function train(){
    if(pet.energy<20){showModal("太累了","体力不足","确定");return;}
    if(pet.sick){showModal("生病了","先看病吧","确定");return;}
    pet.energy=clamp(pet.energy-22);pet.health=clamp(pet.health+5);pet.happy=clamp(pet.happy-5);pet.hunger=clamp(pet.hunger-10);pet.coins+=5;
    showModal("训练","完成训练！健康+5，获得5金币","确定");updateUI();save();
  }
  function buyItem(idx){
    var it=SHOPITEMS[idx];
    if(pet.coins<it.price){showModal("金币不足","需要"+it.price+"金币","确定");return;}
    pet.coins-=it.price;
    if(it.happy)pet.happy=clamp(pet.happy+it.happy);
    if(it.clean)pet.clean=clamp(pet.clean+it.clean);
    if(it.health)pet.health=clamp(pet.health+it.health);
    if(it.energy)pet.energy=clamp(pet.energy+it.energy);
    showModal("购买","买了"+it.name+"！","确定");
    showMain();save();
  }
  function resetPet(){
    localStorage.removeItem("kg_pet2");
    pet={hunger:80,happy:80,clean:80,energy:80,health:100,weight:5,age:0,coins:100,x:130,y:0,dir:1,walkFrame:0,sleeping:false,sick:false,dead:false,action:"idle",actionTimer:0,jumpH:0,loveTimer:0};
    showMain();save();
  }
  function petTap(){
    if(pet.dead||pet.sleeping||getStage()===0)return;
    pet.happy=clamp(pet.happy+3);
    pet.loveTimer=15;
    pet.action="jump";pet.actionTimer=12;pet.jumpH=0;
  }

  function bar(label,val){
    var pct=Math.max(0,Math.min(100,val));
    var filled=Math.round(pct/10);
    var s="";
    for(var i=0;i<10;i++)s+=i<filled?"\u2588":"\u2591";
    return '<div style="font-size:10px;margin:1px 0;text-align:left;">'+label+' '+s+' '+val+'</div>';
  }

  function showMain(){
    panel="main";
    $("gameBody").innerHTML=
      '<canvas id="petCanvas" width="'+W+'" height="'+H+'" style="border:2px solid #000;margin-bottom:4px;cursor:pointer;"></canvas>'+
      '<div id="petStats" style="width:290px;margin:0 auto;"></div>';
    $("gameControls").innerHTML=
      '<button class="btn" id="pFeed" style="width:23%;">喂食</button>'+
      '<button class="btn" id="pPlay" style="width:23%;">玩耍</button>'+
      '<button class="btn" id="pBathe" style="width:23%;">洗澡</button>'+
      '<button class="btn" id="pSleep" style="width:23%;">睡觉</button>'+
      '<br>'+
      '<button class="btn" id="pMed" style="width:23%;">看病</button>'+
      '<button class="btn" id="pWalk" style="width:23%;">散步</button>'+
      '<button class="btn" id="pTrain" style="width:23%;">训练</button>'+
      '<button class="btn" id="pShop" style="width:23%;">商店</button>';
    $("pFeed").onclick=showFeed;
    $("pPlay").onclick=showPlay;
    $("pBathe").onclick=bathe;
    $("pSleep").onclick=toggleSleep;
    $("pMed").onclick=medicine;
    $("pWalk").onclick=walk;
    $("pTrain").onclick=train;
    $("pShop").onclick=showShop;
    $("petCanvas").onclick=function(e){
      var rect=this.getBoundingClientRect();
      var cx=(e.clientX-rect.left)*(W/rect.width);
      var sp=getSprite(),sw=sp[0].length*pxSize(),sh=sp.length*pxSize();
      if(cx>=pet.x-5&&cx<=pet.x+sw+5)petTap();
    };
    updateUI();
  }
  function showFeed(){
    panel="feed";
    var h='<div style="text-align:left;padding:5px;"><div style="font-weight:bold;margin-bottom:6px;">喂食（金币:'+pet.coins+'）</div>';
    for(var i=0;i<FOODS.length;i++){
      var f=FOODS[i],d="饥饿+"+f.hunger;
      if(f.happy)d+=" 心情+"+f.happy;
      if(f.health)d+=" 健康+"+f.health;
      h+='<button class="btn" id="f_'+i+'" style="width:100%;margin:2px 0;text-align:left;font-size:18px;">'+f.name+' - '+d+' ('+f.price+'币)</button>';
    }
    h+='<button class="btn" id="fBack" style="width:100%;margin-top:6px;">返回</button></div>';
    $("gameBody").innerHTML=h;
    for(var i=0;i<FOODS.length;i++)$("f_"+i).onclick=(function(i){return function(){feed(i);};})(i);
    $("fBack").onclick=showMain;
  }
  function showPlay(){
    panel="play";
    $("gameBody").innerHTML='<div style="text-align:left;padding:5px;"><div style="font-weight:bold;margin-bottom:6px;">选择游戏</div>'+
      '<button class="btn" id="plCatch" style="width:100%;margin:2px 0;text-align:left;">接球 - 心情+15 体力-12 赢了+10币</button>'+
      '<button class="btn" id="plRPS" style="width:100%;margin:2px 0;text-align:left;">猜拳 - 心情+10 体力-8 赢了+12币</button>'+
      '<button class="btn" id="plBack" style="width:100%;margin-top:6px;">返回</button></div>';
    $("plCatch").onclick=function(){playGame("catch");};
    $("plRPS").onclick=function(){playGame("rps");};
    $("plBack").onclick=showMain;
  }
  function showShop(){
    panel="shop";
    var h='<div style="text-align:left;padding:5px;"><div style="font-weight:bold;margin-bottom:6px;">商店（金币:'+pet.coins+'）</div>';
    for(var i=0;i<SHOPITEMS.length;i++){
      var it=SHOPITEMS[i],d="";
      if(it.happy)d+="心情+"+it.happy+" ";
      if(it.clean)d+="清洁+"+it.clean+" ";
      if(it.health)d+="健康+"+it.health+" ";
      if(it.energy)d+="体力+"+it.energy+" ";
      h+='<button class="btn" id="s_'+i+'" style="width:100%;margin:2px 0;text-align:left;font-size:18px;">'+it.name+' - '+d+'('+it.price+'币)</button>';
    }
    h+='<button class="btn" id="sReset" style="width:100%;margin:6px 0 2px;text-align:left;font-size:18px;">重置宠物（重新养一只）</button>';
    h+='<button class="btn" id="sBack" style="width:100%;">返回</button></div>';
    $("gameBody").innerHTML=h;
    for(var i=0;i<SHOPITEMS.length;i++)$("s_"+i).onclick=(function(i){return function(){buyItem(i);};})(i);
    $("sReset").onclick=function(){if(confirm("确定要重置宠物吗？"))resetPet();};
    $("sBack").onclick=showMain;
  }

  function tick(){
    if(pet.dead)return;
    tickCount++;
    var r=pet.sleeping?0.3:1;
    pet.hunger=clamp(pet.hunger-0.08*r);
    pet.happy=clamp(pet.happy-0.06*r);
    pet.clean=clamp(pet.clean-0.05*r);
    if(pet.sleeping)pet.energy=clamp(pet.energy+0.5);
    else pet.energy=clamp(pet.energy-0.03*r);
    if(pet.hunger<10||pet.clean<10)pet.health=clamp(pet.health-0.08);
    if(pet.weight>15)pet.health=clamp(pet.health-0.05);
    pet.sick=pet.health<35||(pet.hunger<12&&pet.happy<12)||pet.clean<8;
    if(pet.health<=0){pet.dead=true;save();}
    if(tickCount%100===0){pet.age++;pet.coins+=10;}
    if(tickCount%100===0)save();
    if(pet.loveTimer>0)pet.loveTimer--;
    // 眨眼
    blinkCount++;
    if(blinking){if(blinkCount>2){blinking=false;blinkCount=0;}}
    else if(blinkCount>10+Math.random()*20){blinking=true;blinkCount=0;}
    // 云移动
    for(var i=0;i<clouds.length;i++){
      clouds[i].x-=1.5;
      if(clouds[i].x<-60)clouds[i].x=W+10;
    }
    // 行为状态机
    if(panel==="main"&&!pet.dead){
      pet.actionTimer--;
      if(pet.actionTimer<=0)pickAction();
      var sp=getSprite(),sw=sp[0].length*pxSize();
      if(pet.action==="walk"&&!pet.sleeping&&getStage()>0){
        pet.x+=pet.dir*2;
        if(pet.x<5){pet.x=5;pet.dir=1;}
        if(pet.x>W-sw-5){pet.x=W-sw-5;pet.dir=-1;}
        if(tickCount%2===0)pet.walkFrame=1-pet.walkFrame;
      } else if(pet.action==="jump"){
        var t=10-pet.actionTimer;
        pet.jumpH=Math.sin(t/10*Math.PI)*25;
      } else if(pet.action==="play"){
        pet.x+=pet.dir*3;
        if(pet.x<5||pet.x>W-sw-5)pet.dir=-pet.dir;
      }
    }
    if(panel==="main")updateUI();
  }

  function draw(){
    var canvas=$("petCanvas");
    if(!canvas)return;
    var ctx=canvas.getContext("2d");
    ctx.fillStyle="#fff";ctx.fillRect(0,0,W,H);
    ctx.fillStyle="#000";
    // 云
    for(var i=0;i<clouds.length;i++){
      var cx=clouds[i].x,cy=clouds[i].y;
      ctx.fillRect(cx+6,cy,24,4);
      ctx.fillRect(cx+2,cy+4,32,4);
      ctx.fillRect(cx,cy+8,36,4);
    }
    // 远处的树
    drawSprite(ctx,TREE,30,H-55,2);
    drawSprite(ctx,TREE,250,H-50,2);
    // 地面
    ctx.fillRect(0,H-25,W,2);
    // 草
    for(var i=0;i<W;i+=12){
      if(i%36<12)ctx.fillRect(i,H-22,1,4);
      if(i%48<12)ctx.fillRect(i+5,H-21,1,3);
    }
    // 花
    drawSprite(ctx,FLOWER,80,H-30,2);
    drawSprite(ctx,FLOWER,200,H-28,2);
    if(pet.dead){
      ctx.font="bold 16px monospace";ctx.textAlign="center";
      ctx.fillText("宠物已离开...",W/2,H/2-10);
      ctx.font="12px monospace";
      ctx.fillText("去商店重置一只吧",W/2,H/2+15);
      ctx.textAlign="left";
      return;
    }
    var sprite=getSprite();
    var px=pxSize();
    var sw=sprite[0].length*px,sh=sprite.length*px;
    var x=pet.x,y=H-25-sh-3-pet.jumpH;
    if(getStage()===0){x=W/2-sw/2;}
    // 走路时身体微抖
    var bob=(!pet.sleeping&&getStage()>0&&pet.action==="walk"&&pet.walkFrame===0)?0:1;
    if(pet.action==="sit")bob=3;
    ctx.fillStyle="#000";
    drawSprite(ctx,sprite,x,y+bob,px);
    // 打哈欠
    if(pet.action==="yawn"){
      ctx.font="bold 12px monospace";ctx.textAlign="center";
      ctx.fillText("yawn~",x+sw/2,y-5);
      ctx.textAlign="left";
    }
    // 自己玩
    if(pet.action==="play"){
      ctx.font="bold 10px monospace";ctx.textAlign="center";
      ctx.fillText("*",x+sw/2,y-8);
      ctx.textAlign="left";
    }
    // 睡觉Zzz
    if(pet.sleeping){
      ctx.font="bold 14px monospace";ctx.fillText("Z",x+sw-3,y-5);
      ctx.font="bold 10px monospace";ctx.fillText("z",x+sw+8,y+5);
      ctx.font="bold 8px monospace";ctx.fillText("z",x+sw+16,y+12);
    }
    // 生病
    if(pet.sick){
      ctx.font="bold 14px monospace";ctx.fillText("~",x-8,y+8);
      ctx.fillText("~",x-18,y+18);
    }
    // 爱心（被点击）
    if(pet.loveTimer>0){
      ctx.font="bold 14px monospace";ctx.textAlign="center";
      ctx.fillText("\u2665",x+sw/2,y-12);
      ctx.textAlign="left";
    }
    // 心情气泡
    var m=mood();
    if(m!=="一般"&&m!=="很开心"&&pet.action!=="yawn"&&pet.action!=="play"){
      ctx.font="bold 10px monospace";ctx.textAlign="center";
      ctx.fillText(m,x+sw/2,y-8);
      ctx.textAlign="left";
    }
  }
  function drawSprite(ctx,sprite,x,y,px){
    for(var r=0;r<sprite.length;r++)
      for(var c=0;c<sprite[r].length;c++)
        if(sprite[r][c]==='X')ctx.fillRect(x+c*px,y+r*px,px,px);
  }

  function updateUI(){
    var stats=$("petStats");
    if(stats){
      stats.innerHTML=
        '<div style="float:left;width:48%;">'+bar("饥饿",pet.hunger)+bar("心情",pet.happy)+bar("清洁",pet.clean)+bar("体力",pet.energy)+'</div>'+
        '<div style="float:right;width:48%;">'+bar("健康",pet.health)+
        '<div style="font-size:10px;margin:1px 0;text-align:left;">体重:'+pet.weight+'kg</div>'+
        '<div style="font-size:10px;margin:1px 0;text-align:left;">年龄:'+pet.age+'天 ('+stageName()+')</div>'+
        '<div style="font-size:10px;margin:1px 0;text-align:left;">金币:'+pet.coins+'</div>'+
        '<div style="font-size:10px;margin:1px 0;text-align:left;">状态:'+mood()+'</div></div>'+
        '<div style="clear:both;"></div>';
    }
    draw();
  }

  load();
  if(pet.x===undefined)pet.x=130;
  if(pet.action===undefined){pet.action="idle";pet.actionTimer=10;pet.jumpH=0;pet.loveTimer=0;}
  showMain();
  timer=setInterval(tick,200);
  GAME_CLEANUPS.pet=function(){clearInterval(timer);save();};
};

/* ==================== 14. 猜数字（1A2B） ==================== */
/* ==================== 14. 迷宫 ==================== */
GAME_INITS.bullscows = function(){
  var MW=11, MH=9, CELL=34;
  var walls=[], player={x:0,y:0}, moves=0, over=false;

  function generateMaze(){
    walls=[];
    for(var x=0;x<MW;x++){
      walls[x]=[];
      for(var y=0;y<MH;y++) walls[x][y]={top:true,right:true,bottom:true,left:true};
    }
    var visited=[];
    for(var x=0;x<MW;x++){
      visited[x]=[];
      for(var y=0;y<MH;y++) visited[x][y]=false;
    }
    var stack=[];
    visited[0][0]=true;
    stack.push({x:0,y:0});
    while(stack.length>0){
      var cur=stack[stack.length-1];
      var nbs=[];
      if(cur.y>0 && !visited[cur.x][cur.y-1]) nbs.push({x:cur.x,y:cur.y-1,dir:'top'});
      if(cur.x<MW-1 && !visited[cur.x+1][cur.y]) nbs.push({x:cur.x+1,y:cur.y,dir:'right'});
      if(cur.y<MH-1 && !visited[cur.x][cur.y+1]) nbs.push({x:cur.x,y:cur.y+1,dir:'bottom'});
      if(cur.x>0 && !visited[cur.x-1][cur.y]) nbs.push({x:cur.x-1,y:cur.y,dir:'left'});
      if(nbs.length>0){
        var nxt=nbs[Math.floor(Math.random()*nbs.length)];
        if(nxt.dir==='top'){ walls[cur.x][cur.y].top=false; walls[nxt.x][nxt.y].bottom=false; }
        else if(nxt.dir==='right'){ walls[cur.x][cur.y].right=false; walls[nxt.x][nxt.y].left=false; }
        else if(nxt.dir==='bottom'){ walls[cur.x][cur.y].bottom=false; walls[nxt.x][nxt.y].top=false; }
        else if(nxt.dir==='left'){ walls[cur.x][cur.y].left=false; walls[nxt.x][nxt.y].right=false; }
        visited[nxt.x][nxt.y]=true;
        stack.push({x:nxt.x,y:nxt.y});
      } else {
        stack.pop();
      }
    }
  }

  function init(){
    generateMaze();
    player={x:0,y:0};
    moves=0; over=false;
    $("gameScore").textContent="步数:"+moves+" 最佳:"+getHigh("memory");
  }

  function render(){
    var html='<div style="display:inline-block;border:3px solid #000;background:#fff;">';
    for(var y=0;y<MH;y++){
      html+='<div style="display:block;font-size:0;">';
      for(var x=0;x<MW;x++){
        var w=walls[x][y];
        var borderT=w.top?'2px solid #000':'2px solid #fff';
        var borderR=w.right?'2px solid #000':'2px solid #fff';
        var borderB=w.bottom?'2px solid #000':'2px solid #fff';
        var borderL=w.left?'2px solid #000':'2px solid #fff';
        var bg='#fff';
        var content='';
        // 终点
        if(x===MW-1 && y===MH-1){
          bg='#ddd';
          content='<div style="width:14px;height:14px;border:2px solid #000;display:inline-block;margin-top:5px;"></div>';
        }
        // 玩家
        if(player.x===x && player.y===y){
          bg='#000';
          content='<div style="width:12px;height:12px;background:#fff;border-radius:6px;display:inline-block;margin-top:6px;"></div>';
        }
        html+='<div class="mz-cell" style="width:'+CELL+'px;height:'+CELL+'px;display:inline-block;background:'+bg+';border-top:'+borderT+';border-right:'+borderR+';border-bottom:'+borderB+';border-left:'+borderL+';vertical-align:top;text-align:center;">'+content+'</div>';
      }
      html+='</div>';
    }
    html+='</div>';
    html+='<div style="margin-top:10px;font-size:14px;color:#666;">从左上角走到右下角</div>';
    $("gameBody").innerHTML=html;
  }

  function move(dx,dy){
    if(over) return;
    var w=walls[player.x][player.y];
    if(dx===-1 && w.left) return;
    if(dx===1 && w.right) return;
    if(dy===-1 && w.top) return;
    if(dy===1 && w.bottom) return;
    player.x+=dx; player.y+=dy;
    moves++;
    $("gameScore").textContent="步数:"+moves+" 最佳:"+getHigh("memory");
    render();
    if(player.x===MW-1 && player.y===MH-1){
      over=true;
      setTimeout(function(){ showModal("恭喜！","用了"+moves+"步走出迷宫！","下一关",function(){ init(); render(); }); },200);
    }
  }

  $("gameControls").innerHTML = '<div class="dpad">'
    +'<div class="dpad-row"><span class="dpad-empty"></span><button class="dpad-btn" data-dx="0" data-dy="-1">\u25B2</button><span class="dpad-empty"></span></div>'
    +'<div class="dpad-row"><button class="dpad-btn" data-dx="-1" data-dy="0">\u25C0</button><span class="dpad-empty"></span><button class="dpad-btn" data-dx="1" data-dy="0">\u25B6</button></div>'
    +'<div class="dpad-row"><span class="dpad-empty"></span><button class="dpad-btn" data-dx="0" data-dy="1">\u25BC</button><span class="dpad-empty"></span></div>'
    +'</div> <button class="btn" id="mzNew">新迷宫</button>';
  var dbtns=$("gameControls").getElementsByClassName("dpad-btn");
  for(var i=0;i<dbtns.length;i++){
    dbtns[i].onclick=function(){ move(parseInt(this.getAttribute("data-dx")),parseInt(this.getAttribute("data-dy"))); };
  }
  $("mzNew").onclick=function(){ init(); render(); };
  init();
  render();
};

/* ==================== 15. 小恐龙（Chrome官方精灵精确像素） ==================== */
GAME_INITS.dino = function(){
  var W=540, H=240, GROUND_Y=210, PX=2;
  var dino, obstacles, clouds, score, speed, spawnTimer, cloudTimer, over, timer, frameCount;

  // ===== Chrome官方精灵像素（X=黑，.=透明）=====
  var DINO_BODY = [
    "......................XXXXXXXXXXXXXXXX..",
    "......................XXXXXXXXXXXXXXXX..",
    "....................XXXXXXXXXXXXXXXXXXXX",
    "....................XXXX..XXXXXXXXXXXXXX",
    "....................XXXX..XXXXXXXXXXXXXX",
    "....................XXXXXXXXXXXXXXXXXXXX",
    "....................XXXXXXXXXXXXXXXXXXXX",
    "....................XXXXXXXXXXXXXXXXXXXX",
    "....................XXXXXXXXXXXXXXXXXXXX",
    "....................XXXXXXXXXXXXXXXXXXXX",
    "....................XXXXXXXXXXXXXXXXXXXX",
    "....................XXXXXXXXXX..........",
    "....................XXXXXXXXXX..........",
    "....................XXXXXXXXXXXXXXXX....",
    "....................XXXXXXXXXXXXXXXX....",
    "XX................XXXXXXXXXX............",
    "XX................XXXXXXXXXX............",
    "XX.............XXXXXXXXXXXXX............",
    "XX.............XXXXXXXXXXXXX............",
    "XXXX........XXXXXXXXXXXXXXXXXXXX........",
    "XXXX........XXXXXXXXXXXXXXXXXXXX........",
    "XXXXXX....XXXXXXXXXXXXXXXXXX..XX........",
    "XXXXXX....XXXXXXXXXXXXXXXXXX..XX........",
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXX............",
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXX............",
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXX............",
    "XXXXXXXXXXXXXXXXXXXXXXXXXXXX............",
    "..XXXXXXXXXXXXXXXXXXXXXXXXXX............",
    "..XXXXXXXXXXXXXXXXXXXXXXXX..............",
    "....XXXXXXXXXXXXXXXXXXXXXX..............",
    "....XXXXXXXXXXXXXXXXXXXXXX..............",
    "......XXXXXXXXXXXXXXXXXX................",
    "......XXXXXXXXXXXXXXXXXX................",
    "........XXXXXXXXXXXXXX..................",
    "........XXXXXXXXXXXXXX.................."
  ];
  var DINO_LEGS_STAND = [
    "..........XXXXXX..XXXX..................",
    "..........XXXXXX..XXXX..................",
    "..........XXXX......XX..................",
    "..........XXXX......XX..................",
    "..........XX........XX..................",
    "..........XX........XX..................",
    "..........XXXX......XXXX................",
    "..........XXXX......XXXX................"
  ];
  var DINO_LEGS_RUN = [
    "..........XXXXXX....XXXXX...............",
    "..........XXXXXX....XXXXX...............",
    "..........XXXX..........................",
    "..........XXXX..........................",
    "..........XX............................",
    "..........XX............................",
    "..........XXXX..........................",
    "..........XXXX.........................."
  ];
  var DINO_LEGS_DEAD = [
    "..........XXXX....XXXX..................",
    "..........XXXX....XXXX..................",
    "............XXXX....XX..................",
    "............XXXX....XX..................",
    "....................XX..................",
    "....................XX..................",
    "....................XXXX................",
    "....................XXXX................"
  ];
  var CACTUS_SMALL = [
    "....XXXX.....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "XX.XXXXXX.XX.",
    "XXXXXXXXXXXX.",
    "XXXXXXXXXXXX.",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX....",
    "...XXXXXX...."
  ];
  var CACTUS_LARGE = [
    "......XXXXX......",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    "..X..XXXXXXX..X..",
    ".XXX.XXXXXXX.XXX.",
    ".XXX.XXXXXXX.XXX.",
    ".XXX.XXXXXXX.XXX.",
    ".XXX.XXXXXXX.XXX.",
    ".XXXXXXXXXXXXXXX.",
    ".XXXXXXXXXXXXXXX.",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX.....",
    ".....XXXXXXX....."
  ];
  var CLOUD = [
    "....XXXXXX....",
    "..XXXXXXXXXX..",
    ".XXXXXXXXXXXX.",
    ".XXXXXXXXXXXX.",
    "..XXXXXXXXXX..",
    "....XXXXXX...."
  ];

  function drawSprite(ctx, sprite, x, y){
    for(var r=0;r<sprite.length;r++){
      for(var c=0;c<sprite[r].length;c++){
        if(sprite[r][c]==='X') ctx.fillRect(x+c*PX, y+r*PX, PX, PX);
      }
    }
  }

  function init(){
    dino={x:30, y:GROUND_Y, vy:0, jumping:false, legFrame:0, dead:false};
    obstacles=[]; clouds=[];
    score=0; speed=10; spawnTimer=60; cloudTimer=80; over=false; frameCount=0;
    $("gameScore").textContent="分数:0";
  }

  function jump(){
    if(!dino.jumping && !over){
      dino.vy=-13;
      dino.jumping=true;
    }
  }

  function spawnObstacle(){
    var r=Math.random();
    if(r<0.5){
      obstacles.push({sprite:CACTUS_SMALL, x:W, y:GROUND_Y-CACTUS_SMALL.length*PX, w:CACTUS_SMALL[0].length*PX, h:CACTUS_SMALL.length*PX});
    } else if(r<0.8){
      obstacles.push({sprite:CACTUS_LARGE, x:W, y:GROUND_Y-CACTUS_LARGE.length*PX, w:CACTUS_LARGE[0].length*PX, h:CACTUS_LARGE.length*PX});
    } else {
      obstacles.push({sprite:CACTUS_SMALL, x:W, y:GROUND_Y-CACTUS_SMALL.length*PX, w:CACTUS_SMALL[0].length*PX, h:CACTUS_SMALL.length*PX});
      obstacles.push({sprite:CACTUS_SMALL, x:W+CACTUS_SMALL[0].length*PX+6, y:GROUND_Y-CACTUS_SMALL.length*PX, w:CACTUS_SMALL[0].length*PX, h:CACTUS_SMALL.length*PX});
    }
  }

  function update(){
    if(over) return;
    frameCount++;
    if(dino.jumping){
      dino.vy+=0.7;
      dino.y+=dino.vy;
      if(dino.y>=GROUND_Y){ dino.y=GROUND_Y; dino.vy=0; dino.jumping=false; }
    }
    if(frameCount%4===0 && !dino.jumping) dino.legFrame=1-dino.legFrame;
    for(var i=obstacles.length-1;i>=0;i--){
      obstacles[i].x-=speed;
      if(obstacles[i].x+obstacles[i].w<0) obstacles.splice(i,1);
    }
    spawnTimer--;
    if(spawnTimer<=0){ spawnObstacle(); spawnTimer=45+Math.floor(Math.random()*55); }
    cloudTimer--;
    if(cloudTimer<=0 && clouds.length<3){
      clouds.push({x:W, y:15+Math.floor(Math.random()*50)});
      cloudTimer=100+Math.floor(Math.random()*80);
    }
    for(var i=clouds.length-1;i>=0;i--){
      clouds[i].x-=1.5;
      if(clouds[i].x<-CLOUD[0].length*PX) clouds.splice(i,1);
    }
    // 碰撞盒
    var db={x:dino.x+12, y:dino.y-DINO_BODY.length*PX-DINO_LEGS_STAND.length*PX+8, w:50, h:DINO_BODY.length*PX+DINO_LEGS_STAND.length*PX-12};
    for(var i=0;i<obstacles.length;i++){
      var o=obstacles[i];
      if(db.x<o.x+o.w-6 && db.x+db.w>o.x+6 && db.y<o.y+o.h && db.y+db.h>o.y+6){
        gameOver(); return;
      }
    }
    score++;
    if(score%5===0) $("gameScore").textContent="分数:"+Math.floor(score/3);
    if(score%150===0 && speed<16) speed+=1;
    draw();
  }

  function draw(){
    var canvas=$("dinoCanvas");
    if(!canvas) return;
    var ctx=canvas.getContext("2d");
    ctx.fillStyle="#fff"; ctx.fillRect(0,0,W,H);
    ctx.fillStyle="#000";
    // 云
    for(var i=0;i<clouds.length;i++) drawSprite(ctx, CLOUD, clouds[i].x, clouds[i].y);
    // 地面
    ctx.fillRect(0, GROUND_Y, W, 2);
    // 地面小石子
    for(var i=0;i<W;i+=10){
      var off=((i+Math.floor(score*speed*0.2))%W);
      if(off%41<3) ctx.fillRect(off, GROUND_Y+5, 3, 2);
      if(off%59<2) ctx.fillRect(off+5, GROUND_Y+8, 2, 2);
    }
    // 恐龙身体
    var bodyY=dino.y-DINO_BODY.length*PX-DINO_LEGS_STAND.length*PX;
    drawSprite(ctx, DINO_BODY, dino.x, bodyY);
    // 恐龙腿
    var legY=dino.y-DINO_LEGS_STAND.length*PX;
    if(dino.dead){
      drawSprite(ctx, DINO_LEGS_DEAD, dino.x, legY);
    } else if(dino.jumping){
      drawSprite(ctx, DINO_LEGS_STAND, dino.x, legY);
    } else if(dino.legFrame===0){
      drawSprite(ctx, DINO_LEGS_STAND, dino.x, legY);
    } else {
      drawSprite(ctx, DINO_LEGS_RUN, dino.x, legY);
    }
    // 仙人掌
    for(var i=0;i<obstacles.length;i++){
      drawSprite(ctx, obstacles[i].sprite, obstacles[i].x, obstacles[i].y);
    }
  }

  function gameOver(){
    over=true; dino.dead=true;
    clearInterval(timer);
    var fs=Math.floor(score/3);
    draw();
    setTimeout(function(){ showModal("GAME OVER","得分:"+fs,"再来一局",function(){ startGame("dino"); }); },300);
  }

  $("gameBody").innerHTML='<canvas id="dinoCanvas" width="'+W+'" height="'+H+'" style="border:2px solid #000;"></canvas>';
  $("gameControls").innerHTML='<button class="btn" id="dinoJump" style="padding:15px 60px;font-size:20px;">跳跃</button> <button class="btn" id="dinoRestart">重开</button>';
  $("dinoJump").onclick=jump;
  $("dinoRestart").onclick=function(){ startGame("dino"); };
  $("dinoCanvas").onclick=jump;
  init();
  draw();
  timer=setInterval(update, 40);
  GAME_CLEANUPS.dino = function(){ clearInterval(timer); };
};

/* ==================== 16. 猜瓶子 ==================== */
GAME_INITS.shell = function(){
  var W=420, H=320;
  var cups=[{x:70,y:210},{x:175,y:210},{x:280,y:210}];
  var ballCup=1, phase="idle", shuffleCount=0, shuffleTotal=0;
  var score=0, level=1, resultMsg="";

  function draw(){
    var canvas=$("shellCanvas"); if(!canvas)return;
    var ctx=canvas.getContext("2d");
    ctx.fillStyle="#fff";ctx.fillRect(0,0,W,H);
    ctx.fillStyle="#000";
    ctx.fillRect(20,H-50,W-40,2);
    if(phase==="showing"||phase==="result"){
      var bc=cups[ballCup];
      ctx.beginPath();ctx.arc(bc.x+35,H-62,12,0,Math.PI*2);ctx.fill();
    }
    for(var i=0;i<cups.length;i++){
      var c=cups[i],lift=0;
      if((phase==="showing"||phase==="result")&&i===ballCup)lift=-56;
      drawCup(ctx,c.x,c.y+lift);
    }
    ctx.font="bold 14px monospace";ctx.textAlign="center";
    var msg="";
    if(phase==="idle")msg="点击开始";
    else if(phase==="showing")msg="看好了！";
    else if(phase==="shuffling")msg="交换中... 剩"+(shuffleTotal-shuffleCount)+"次";
    else if(phase==="guessing")msg="球在哪个杯子下？";
    else if(phase==="result")msg=resultMsg;
    ctx.fillText(msg,W/2,30);
    ctx.font="12px monospace";
    ctx.fillText("得分:"+score+"  关卡:"+level+"  最高:"+getHigh("shell"),W/2,52);
    ctx.textAlign="left";
  }
  function drawCup(ctx,x,y){
    ctx.fillStyle="#000";
    ctx.fillRect(x,y+56,70,5);
    for(var i=0;i<56;i++){
      var w=70-i*0.7,off=(70-w)/2;
      ctx.fillRect(x+off,y+i,w,1);
    }
    ctx.fillRect(x+18,y-3,34,5);
    ctx.fillStyle="#fff";ctx.fillRect(x+10,y+14,5,28);ctx.fillStyle="#000";
  }
  function startRound(){
    phase="showing";ballCup=Math.floor(Math.random()*3);
    shuffleTotal=3+level*2;shuffleCount=0;
    draw();
    setTimeout(function(){phase="shuffling";doShuffle();},1200);
  }
  function doShuffle(){
    if(shuffleCount>=shuffleTotal){phase="guessing";draw();return;}
    var a=Math.floor(Math.random()*3),b=Math.floor(Math.random()*3);
    while(b===a)b=Math.floor(Math.random()*3);
    var sx=[cups[0].x,cups[1].x,cups[2].x];
    var ex=[sx[0],sx[1],sx[2]];ex[a]=sx[b];ex[b]=sx[a];
    var frames=15,f=0;
    var at=setInterval(function(){
      f++;var t=f/frames;
      for(var i=0;i<3;i++)cups[i].x=sx[i]+(ex[i]-sx[i])*t;
      draw();
      if(f>=frames){
        clearInterval(at);
        var ballCupRef=cups[ballCup];
        var sorted=cups.slice().sort(function(a,b){return a.x-b.x;});
        for(var si=0;si<3;si++){if(sorted[si]===ballCupRef)ballCup=si;}
        cups=sorted;
        shuffleCount++;setTimeout(doShuffle,100);
      }
    },30);
  }
  function guess(idx){
    if(phase!=="guessing")return;
    phase="result";
    if(idx===ballCup){score+=10*level;resultMsg="猜对了！+"+(10*level)+"分";level++;}
    else{resultMsg="猜错了！是第"+(ballCup+1)+"个";score=Math.max(0,score-5);if(level>1)level--;}
    draw();
  }
  $("gameBody").innerHTML='<canvas id="shellCanvas" width="'+W+'" height="'+H+'" style="border:2px solid #000;max-width:100%;"></canvas>';
  $("gameControls").innerHTML='<button class="btn" id="shStart" style="width:28%;">开始</button>'
    +'<button class="btn" id="sh0" style="width:20%;">杯1</button>'
    +'<button class="btn" id="sh1" style="width:20%;">杯2</button>'
    +'<button class="btn" id="sh2" style="width:20%;">杯3</button>';
  $("shStart").onclick=startRound;
  $("sh0").onclick=function(){guess(0);};
  $("sh1").onclick=function(){guess(1);};
  $("sh2").onclick=function(){guess(2);};
  draw();
};

/* ==================== 17. 水管连接 ==================== */
GAME_INITS.pipe = function(){
  var CELL=64, rows=6, cols=6, grid=[], level=1, maxLevel=20, moves=0;
  var DR=[-1,0,1,0],DC=[0,1,0,-1],OPP=[4,8,1,2];
  function rotate(d){return ((d<<1)&15)|((d>>3)&1);}
  function generateLevel(){
    grid=[];
    for(var r=0;r<rows;r++){grid[r]=[];for(var c=0;c<cols;c++)grid[r][c]={conn:0,fixed:false};}
    var path=[],r=0,c=0;path.push([r,c]);
    var guard=0;
    while((r<rows-1||c<cols-1)&&guard<200){
      guard++;
      var opts=[];
      if(r<rows-1)opts.push(2);if(c<cols-1)opts.push(1);
      if(level>5&&r>0&&Math.random()<0.2)opts.push(0);
      if(level>8&&c>0&&Math.random()<0.2)opts.push(3);
      var dir=opts[Math.floor(Math.random()*opts.length)];
      r+=DR[dir];c+=DC[dir];
      var dup=false;
      for(var i=0;i<path.length;i++)if(path[i][0]===r&&path[i][1]===c){dup=true;break;}
      if(dup){r-=DR[dir];c-=DC[dir];continue;}
      path.push([r,c]);
    }
    for(var i=0;i<path.length;i++){
      var pr=path[i][0],pc=path[i][1],conn=0;
      if(i>0){var pv=path[i-1],dr=pv[0]-pr,dc=pv[1]-pc;
        if(dr===-1)conn|=1;if(dc===1)conn|=2;if(dr===1)conn|=4;if(dc===-1)conn|=8;}
      if(i<path.length-1){var nx=path[i+1],dr2=nx[0]-pr,dc2=nx[1]-pc;
        if(dr2===-1)conn|=1;if(dc2===1)conn|=2;if(dr2===1)conn|=4;if(dc2===-1)conn|=8;}
      grid[pr][pc].conn=conn;
    }
    grid[0][0].fixed=true;grid[rows-1][cols-1].fixed=true;
    var ptypes=[5,10,3,6,12,9,7,14,13,11,15];
    for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){
      if(grid[r][c].conn===0)grid[r][c].conn=ptypes[Math.floor(Math.random()*ptypes.length)];
      if(!grid[r][c].fixed){var rot=Math.floor(Math.random()*4);for(var k=0;k<rot;k++)grid[r][c].conn=rotate(grid[r][c].conn);}
    }
    moves=0;
  }
  function getConnected(){
    var vis=[];for(var r=0;r<rows;r++){vis[r]=[];for(var c=0;c<cols;c++)vis[r][c]=false;}
    var q=[[0,0]];vis[0][0]=true;
    while(q.length>0){
      var cur=q.shift(),cr=cur[0],cc=cur[1],cn=grid[cr][cc].conn;
      for(var d=0;d<4;d++){var bit=[1,2,4,8][d];
        if(cn&bit){var nr=cr+DR[d],nc=cc+DC[d];
          if(nr>=0&&nr<rows&&nc>=0&&nc<cols&&!vis[nr][nc]&&(grid[nr][nc].conn&OPP[d])){vis[nr][nc]=true;q.push([nr,nc]);}}}
    }
    return vis;
  }
  function checkWin(){var v=getConnected();return v[rows-1][cols-1];}
  function draw(){
    var canvas=$("pipeCanvas");if(!canvas)return;
    var ctx=canvas.getContext("2d");var W=cols*CELL,H=rows*CELL;
    ctx.fillStyle="#fff";ctx.fillRect(0,0,W,H);
    var conn=getConnected();
    for(var r=0;r<rows;r++)for(var c=0;c<cols;c++){
      var x=c*CELL,y=r*CELL;
      ctx.fillStyle=conn[r][c]?"#ddd":"#fff";ctx.fillRect(x,y,CELL,CELL);
      ctx.strokeStyle="#000";ctx.lineWidth=1;ctx.strokeRect(x,y,CELL,CELL);
      drawPipe(ctx,x,y,grid[r][c].conn,conn[r][c]);
      if(r===0&&c===0){ctx.fillStyle="#000";ctx.font="bold 10px monospace";ctx.fillText("入",x+4,y+12);}
      if(r===rows-1&&c===cols-1){ctx.fillStyle="#000";ctx.font="bold 10px monospace";ctx.fillText("出",x+CELL-16,y+CELL-4);}
    }
  }
  function drawPipe(ctx,x,y,cn,water){
    var cx=x+CELL/2,cy=y+CELL/2,half=CELL/2-4;
    ctx.fillStyle=water?"#000":"#555";
    ctx.beginPath();ctx.arc(cx,cy,6,0,Math.PI*2);ctx.fill();
    if(cn&1)ctx.fillRect(cx-5,y+2,10,half);
    if(cn&2)ctx.fillRect(cx,cy-5,half,10);
    if(cn&4)ctx.fillRect(cx-5,cy,10,half);
    if(cn&8)ctx.fillRect(x+2,cy-5,half,10);
    ctx.fillStyle=water?"#999":"#fff";
    if(cn&1)ctx.fillRect(cx-2,y+4,4,half-2);
    if(cn&2)ctx.fillRect(cx+2,cy-2,half-2,4);
    if(cn&4)ctx.fillRect(cx-2,cy+2,4,half-2);
    if(cn&8)ctx.fillRect(x+4,cy-2,half-2,4);
    ctx.beginPath();ctx.arc(cx,cy,3,0,Math.PI*2);ctx.fill();
  }
  function clickCell(r,c){
    if(grid[r][c].fixed)return;
    grid[r][c].conn=rotate(grid[r][c].conn);moves++;draw();
    if(checkWin())setTimeout(function(){
      if(level<maxLevel)showModal("通关！","第"+level+"关完成，用了"+moves+"步","下一关",function(){level++;generateLevel();draw();updateInfo();});
      else showModal("全部通关！","完成了全部"+maxLevel+"关！","重新开始",function(){level=1;generateLevel();draw();updateInfo();});
    },300);
  }
  function updateInfo(){$("gameScore").textContent="第"+level+"/"+maxLevel+"关  步数:"+moves;}
  var W=cols*CELL,H=rows*CELL;
  $("gameBody").innerHTML='<canvas id="pipeCanvas" width="'+W+'" height="'+H+'" style="border:2px solid #000;"></canvas>';
  $("gameControls").innerHTML='<button class="btn" id="pipeReset" style="width:40%;">重置本关</button><button class="btn" id="pipeSkip" style="width:40%;">跳过本关</button>';
  $("pipeCanvas").onclick=function(e){
    var rect=this.getBoundingClientRect();
    var x=(e.clientX-rect.left)*(W/rect.width),y=(e.clientY-rect.top)*(H/rect.height);
    var c=Math.floor(x/CELL),r=Math.floor(y/CELL);
    if(r>=0&&r<rows&&c>=0&&c<cols)clickCell(r,c);
  };
  $("pipeReset").onclick=function(){generateLevel();draw();updateInfo();};
  $("pipeSkip").onclick=function(){if(level<maxLevel){level++;generateLevel();draw();updateInfo();}};
  generateLevel();draw();updateInfo();
};

/* ==================== 18. 围棋 9x9 ==================== */
GAME_INITS.go = function(){
  var SIZE=9,CELL=44,PAD=24,board=[],current=1,mode="pve";
  var capB=0,capW=0,lastMove=null,koPoint=null,passCount=0,gameOver=false;
  function initBoard(){board=[];for(var i=0;i<SIZE;i++){board[i]=[];for(var j=0;j<SIZE;j++)board[i][j]=0;}current=1;capB=0;capW=0;lastMove=null;koPoint=null;passCount=0;gameOver=false;}
  function getNeighbors(r,c){var n=[];if(r>0)n.push([r-1,c]);if(r<SIZE-1)n.push([r+1,c]);if(c>0)n.push([r,c-1]);if(c<SIZE-1)n.push([r,c+1]);return n;}
  function getGroup(r,c){
    var color=board[r][c];if(color===0)return {stones:[],libs:{}};
    var vis={},stones=[],libs={},stack=[[r,c]];vis[r+","+c]=true;
    while(stack.length>0){
      var cur=stack.pop();stones.push(cur);
      var ns=getNeighbors(cur[0],cur[1]);
      for(var i=0;i<ns.length;i++){
        var nr=ns[i][0],nc=ns[i][1],key=nr+","+nc;
        if(board[nr][nc]===0)libs[key]=true;
        else if(board[nr][nc]===color&&!vis[key]){vis[key]=true;stack.push([nr,nc]);}
      }
    }
    return {stones:stones,libs:libs};
  }
  function countLibs(g){var n=0;for(var k in g.libs)n++;return n;}
  function placeStone(r,c,color){
    if(board[r][c]!==0)return false;
    if(koPoint&&koPoint[0]===r&&koPoint[1]===c)return false;
    board[r][c]=color;var opp=color===1?2:1,captured=[];
    var ns=getNeighbors(r,c);
    for(var i=0;i<ns.length;i++){
      var nr=ns[i][0],nc=ns[i][1];
      if(board[nr][nc]===opp){var g=getGroup(nr,nc);
        if(countLibs(g)===0){for(var j=0;j<g.stones.length;j++){captured.push(g.stones[j]);board[g.stones[j][0]][g.stones[j][1]]=0;}}}
    }
    var myG=getGroup(r,c);
    if(countLibs(myG)===0&&captured.length===0){board[r][c]=0;return false;}
    if(captured.length===1&&myG.stones.length===1&&countLibs(myG)===1)koPoint=[captured[0][0],captured[0][1]];else koPoint=null;
    if(color===1)capW+=captured.length;else capB+=captured.length;
    lastMove=[r,c];passCount=0;return true;
  }
  function aiMove(){
    var opp=current===1?2:1;
    var caps=[];
    for(var r=0;r<SIZE;r++)for(var c=0;c<SIZE;c++){
      if(board[r][c]!==0||(koPoint&&koPoint[0]===r&&koPoint[1]===c))continue;
      board[r][c]=current;var cap=0;
      var ns=getNeighbors(r,c);
      for(var i=0;i<ns.length;i++){var nr=ns[i][0],nc=ns[i][1];
        if(board[nr][nc]===opp){var g=getGroup(nr,nc);if(countLibs(g)===0)cap+=g.stones.length;}}
      var myG=getGroup(r,c);board[r][c]=0;
      if(cap>0&&countLibs(myG)>0)caps.push([r,c,cap]);
    }
    if(caps.length>0){caps.sort(function(a,b){return b[2]-a[2];});return [caps[0][0],caps[0][1]];}
    var saves=[];
    for(var r=0;r<SIZE;r++)for(var c=0;c<SIZE;c++){
      if(board[r][c]!==current)continue;
      var g=getGroup(r,c);
      if(countLibs(g)===1){for(var k in g.libs){var p=k.split(",");var lr=parseInt(p[0]),lc=parseInt(p[1]);
        board[lr][lc]=current;var ng=getGroup(lr,lc);board[lr][lc]=0;
        if(countLibs(ng)>1)saves.push([lr,lc]);}}}
    if(saves.length>0)return saves[Math.floor(Math.random()*saves.length)];
    var stars=[[2,2],[2,6],[6,2],[6,6],[4,4],[0,0],[0,8],[8,0],[8,8]];
    for(var i=0;i<stars.length;i++){var sp=stars[i];
      if(board[sp[0]][sp[1]]===0&&!(koPoint&&koPoint[0]===sp[0]&&koPoint[1]===sp[1])){
        board[sp[0]][sp[1]]=current;var g=getGroup(sp[0],sp[1]);board[sp[0]][sp[1]]=0;
        if(countLibs(g)>0)return sp;}}
    var legal=[];
    for(var r=0;r<SIZE;r++)for(var c=0;c<SIZE;c++){
      if(board[r][c]!==0||(koPoint&&koPoint[0]===r&&koPoint[1]===c))continue;
      board[r][c]=current;var g=getGroup(r,c);board[r][c]=0;
      if(countLibs(g)>0)legal.push([r,c]);
    }
    if(legal.length>0)return legal[Math.floor(Math.random()*legal.length)];
    return null;
  }
  function draw(){
    var canvas=$("goCanvas");if(!canvas)return;
    var ctx=canvas.getContext("2d");var W=PAD*2+CELL*(SIZE-1),H=PAD*2+CELL*(SIZE-1);
    ctx.fillStyle="#fff";ctx.fillRect(0,0,W,H);
    ctx.strokeStyle="#000";ctx.lineWidth=1;
    for(var i=0;i<SIZE;i++){
      ctx.beginPath();ctx.moveTo(PAD,PAD+i*CELL);ctx.lineTo(PAD+(SIZE-1)*CELL,PAD+i*CELL);ctx.stroke();
      ctx.beginPath();ctx.moveTo(PAD+i*CELL,PAD);ctx.lineTo(PAD+i*CELL,PAD+(SIZE-1)*CELL);ctx.stroke();
    }
    ctx.fillStyle="#000";
    var sp=[[2,2],[2,6],[6,2],[6,6],[4,4]];
    for(var i=0;i<sp.length;i++){ctx.beginPath();ctx.arc(PAD+sp[i][1]*CELL,PAD+sp[i][0]*CELL,3,0,Math.PI*2);ctx.fill();}
    for(var r=0;r<SIZE;r++)for(var c=0;c<SIZE;c++){
      if(board[r][c]!==0){
        var x=PAD+c*CELL,y=PAD+r*CELL;
        ctx.fillStyle="#ccc";ctx.beginPath();ctx.arc(x+1,y+1,CELL/2-2,0,Math.PI*2);ctx.fill();
        ctx.fillStyle=board[r][c]===1?"#000":"#fff";
        ctx.beginPath();ctx.arc(x,y,CELL/2-2,0,Math.PI*2);ctx.fill();
        ctx.strokeStyle="#000";ctx.lineWidth=1;ctx.stroke();
        if(board[r][c]===2){ctx.fillStyle="#ddd";ctx.beginPath();ctx.arc(x-3,y-3,3,0,Math.PI*2);ctx.fill();}
      }
    }
    if(lastMove){
      var lx=PAD+lastMove[1]*CELL,ly=PAD+lastMove[0]*CELL;
      ctx.strokeStyle=board[lastMove[0]][lastMove[1]]===1?"#fff":"#000";ctx.lineWidth=2;
      ctx.beginPath();ctx.arc(lx,ly,5,0,Math.PI*2);ctx.stroke();
    }
    ctx.fillStyle="#000";ctx.font="9px monospace";
    for(var i=0;i<SIZE;i++){ctx.fillText(String.fromCharCode(65+i),PAD+i*CELL-3,H-4);ctx.fillText((SIZE-i).toString(),2,PAD+i*CELL+3);}
  }
  function doMove(r,c){
    if(gameOver||(mode==="pve"&&current===2))return;
    if(!placeStone(r,c,current))return;
    current=current===1?2:1;draw();updateInfo();
    if(mode==="pve"&&current===2&&!gameOver)setTimeout(function(){
      var mv=aiMove();
      if(mv)placeStone(mv[0],mv[1],2);else passCount++;
      current=1;draw();updateInfo();
      if(passCount>=2)endGame();
    },500);
  }
  function pass(){
    if(gameOver)return;passCount++;koPoint=null;current=current===1?2:1;draw();updateInfo();
    if(passCount>=2)endGame();
    else if(mode==="pve"&&current===2)setTimeout(function(){
      var mv=aiMove();if(mv)placeStone(mv[0],mv[1],2);else passCount++;
      current=1;draw();updateInfo();if(passCount>=2)endGame();
    },500);
  }
  function endGame(){
    gameOver=true;var bc=0,wc=0;
    for(var r=0;r<SIZE;r++)for(var c=0;c<SIZE;c++){if(board[r][c]===1)bc++;else if(board[r][c]===2)wc++;}
    bc+=capW;wc+=capB+5.5;
    var winner=bc>wc?"黑棋":"白棋";
    showModal("对局结束","黑:"+bc+"  白:"+wc+"\n"+winner+"胜!","再来一局",function(){initBoard();draw();updateInfo();});
  }
  function updateInfo(){var t=current===1?"黑棋":"白棋";$("gameScore").textContent=t+"走  提子:黑"+capW+"/白"+capB;}
  var W=PAD*2+CELL*(SIZE-1),H=PAD*2+CELL*(SIZE-1);
  $("gameBody").innerHTML='<canvas id="goCanvas" width="'+W+'" height="'+H+'" style="border:2px solid #000;"></canvas>';
  $("gameControls").innerHTML='<button class="btn" id="goMode" style="width:35%;">人机</button><button class="btn" id="goRestart" style="width:35%;">重开</button>';
  $("goCanvas").onclick=function(e){
    var rect=this.getBoundingClientRect();
    var x=(e.clientX-rect.left)*(W/rect.width),y=(e.clientY-rect.top)*(H/rect.height);
    var c=Math.round((x-PAD)/CELL),r=Math.round((y-PAD)/CELL);
    if(r>=0&&r<SIZE&&c>=0&&c<SIZE)doMove(r,c);
  };
  $("goMode").onclick=function(){mode=mode==="pve"?"pvp":"pve";this.textContent=mode==="pve"?"人机":"双人";initBoard();draw();updateInfo();};
  $("goRestart").onclick=function(){initBoard();draw();updateInfo();};
  initBoard();draw();updateInfo();
};

/* ==================== 19. 饼干点击器 ==================== */
GAME_INITS.cookie = function(){
  var cookies=0,totalClicks=0,totalCookies=0,cps=0,clickPower=1;
  var timer=null,bonusTimer=null,bonusActive=false,bonusX=0,bonusY=0,bonusType=0;
  var achievements=[],floatTexts=[];
  var bonusInfo=[
    {name:"银饼",mult:0.05,base:5,weight:60},
    {name:"金饼",mult:0.1,base:50,weight:30},
    {name:"钻石饼",mult:0.25,base:200,weight:10}
  ];
  var upgrades=[
    {id:"cursor",name:"光标",baseCost:15,cps:0.1,owned:0},
    {id:"grandma",name:"老奶奶",baseCost:100,cps:1,owned:0},
    {id:"farm",name:"农场",baseCost:1100,cps:8,owned:0},
    {id:"factory",name:"工厂",baseCost:12000,cps:47,owned:0},
    {id:"bank",name:"银行",baseCost:130000,cps:260,owned:0},
    {id:"temple",name:"寺庙",baseCost:1400000,cps:1400,owned:0},
    {id:"tower",name:"巫师塔",baseCost:20000000,cps:7800,owned:0},
    {id:"click1",name:"耐用手指",baseCost:500,click:1,owned:0,max:1},
    {id:"click2",name:"铁手指",baseCost:5000,click:5,owned:0,max:1},
    {id:"click3",name:"黄金手指",baseCost:50000,click:20,owned:0,max:1},
    {id:"click4",name:"钻石手指",baseCost:500000,click:100,owned:0,max:1}
  ];
  function saveCookie(){
    try{
      var data={cookies:cookies,totalClicks:totalClicks,totalCookies:totalCookies,clickPower:clickPower,ups:[]};
      for(var i=0;i<upgrades.length;i++)data.ups.push(upgrades[i].owned);
      localStorage.setItem("kg_cookie",JSON.stringify(data));
    }catch(e){}
  }
  function loadCookie(){
    try{
      var s=localStorage.getItem("kg_cookie");
      if(s){
        var d=JSON.parse(s);
        cookies=d.cookies||0;totalClicks=d.totalClicks||0;totalCookies=d.totalCookies||0;clickPower=d.clickPower||1;
        if(d.ups){for(var i=0;i<d.ups.length&&i<upgrades.length;i++){
          upgrades[i].owned=d.ups[i];
          if(upgrades[i].cps)cps+=upgrades[i].cps*upgrades[i].owned;
        }}
      }
    }catch(e){}
  }
  function getHighScore(){
    try{return parseInt(localStorage.getItem("kg_cookie_high")||"0");}catch(e){return 0;}
  }
  function checkHighScore(){
    if(totalCookies>getHighScore()){
      try{localStorage.setItem("kg_cookie_high",Math.floor(totalCookies));}catch(e){}
    }
  }
  function getCost(up){return Math.floor(up.baseCost*Math.pow(1.15,up.owned));}
  function buyUp(idx){
    var up=upgrades[idx];
    if(up.max&&up.owned>=up.max)return;
    var cost=getCost(up);if(cookies<cost)return;
    cookies-=cost;up.owned++;
    if(up.cps)cps+=up.cps;if(up.click)clickPower+=up.click;
    updateUI();
  }
  function spawnFloat(x,y,text){floatTexts.push({x:x,y:y,text:text,life:20});}
  function clickCookie(e){
    if(e){
      var canvas=$("cookieCanvas");if(canvas){var rect=canvas.getBoundingClientRect();
      var x=(e.clientX-rect.left)*(420/rect.width),y=(e.clientY-rect.top)*(280/rect.height);
      var dx=x-210,dy=y-140;
      if(dx*dx+dy*dy>110*110)return;
      spawnFloat(x,y,"+"+clickPower);}}
    cookies+=clickPower;totalCookies+=clickPower;totalClicks++;
    checkAch();saveCookie();updateUI();
  }
  function drawCookie(){
    var canvas=$("cookieCanvas");if(!canvas)return;
    var ctx=canvas.getContext("2d");
    ctx.fillStyle="#fff";ctx.fillRect(0,0,420,280);
    var cx=210,cy=140,r=100;
    ctx.fillStyle="#000";ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(cx,cy,r-4,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#000";
    var chips=[[-28,-21],[-7,-35],[21,-14],[-35,14],[7,7],[28,28],[-14,35],[0,0]];
    for(var i=0;i<chips.length;i++){ctx.beginPath();ctx.arc(cx+chips[i][0],cy+chips[i][1],7,0,Math.PI*2);ctx.fill();}
    ctx.strokeStyle="#000";ctx.lineWidth=1;
    for(var a=0;a<360;a+=15){var rad=a*Math.PI/180;
      ctx.beginPath();ctx.moveTo(cx+Math.cos(rad)*(r-4),cy+Math.sin(rad)*(r-4));
      ctx.lineTo(cx+Math.cos(rad)*(r-1),cy+Math.sin(rad)*(r-1));ctx.stroke();}
    if(bonusActive){
      if(bonusType===0){
        ctx.strokeStyle="#000";ctx.lineWidth=3;ctx.beginPath();ctx.arc(bonusX,bonusY,26,0,Math.PI*2);ctx.stroke();
        ctx.fillStyle="#000";ctx.font="bold 14px monospace";ctx.textAlign="center";ctx.fillText("银",bonusX,bonusY+5);ctx.textAlign="left";
      }else if(bonusType===1){
        ctx.fillStyle="#000";ctx.beginPath();ctx.arc(bonusX,bonusY,28,0,Math.PI*2);ctx.fill();
        ctx.fillStyle="#fff";ctx.font="bold 14px monospace";ctx.textAlign="center";ctx.fillText("金",bonusX,bonusY+5);ctx.textAlign="left";
      }else{
        ctx.save();ctx.translate(bonusX,bonusY);ctx.rotate(Math.PI/4);
        ctx.fillStyle="#000";ctx.fillRect(-22,-22,44,44);
        ctx.fillStyle="#fff";ctx.fillRect(-16,-16,32,32);
        ctx.restore();
        ctx.fillStyle="#000";ctx.font="bold 14px monospace";ctx.textAlign="center";ctx.fillText("钻",bonusX,bonusY+5);ctx.textAlign="left";
      }
    }
    for(var i=floatTexts.length-1;i>=0;i--){
      var ft=floatTexts[i];
      ctx.fillStyle="#000";ctx.font="bold 12px monospace";ctx.globalAlpha=ft.life/20;
      ctx.fillText(ft.text,ft.x,ft.y);ctx.globalAlpha=1;
      ft.y-=1;ft.life--;if(ft.life<=0)floatTexts.splice(i,1);
    }
  }
  function spawnBonus(){
    if(bonusActive)return;
    var roll=Math.random()*100,acc=0;
    for(var t=0;t<bonusInfo.length;t++){acc+=bonusInfo[t].weight;if(roll<acc){bonusType=t;break;}}
    bonusActive=true;bonusX=60+Math.random()*300;bonusY=50+Math.random()*180;
    drawCookie();
    setTimeout(function(){if(bonusActive){bonusActive=false;drawCookie();}},10000);
  }
  function clickBonus(e){
    if(!bonusActive)return false;
    var canvas=$("cookieCanvas");var rect=canvas.getBoundingClientRect();
    var x=(e.clientX-rect.left)*(420/rect.width),y=(e.clientY-rect.top)*(280/rect.height);
    var dx=x-bonusX,dy=y-bonusY;
    if(dx*dx+dy*dy<900){
      bonusActive=false;
      var bi=bonusInfo[bonusType];
      var bonus=Math.max(bi.base,Math.floor(cookies*bi.mult))+bi.base;
      cookies+=bonus;totalCookies+=bonus;
      spawnFloat(bonusX,bonusY,"+"+bonus+"!");
      showModal(bi.name+"!","获得 "+bonus+" 饼干!","太棒了");
      checkAch();updateUI();return true;
    }
    return false;
  }
  function checkAch(){
    if(totalClicks>=100&&achievements.indexOf("click100")<0)achievements.push("click100");
    if(totalClicks>=1000&&achievements.indexOf("click1000")<0)achievements.push("click1000");
    if(totalCookies>=1000&&achievements.indexOf("cookie1000")<0)achievements.push("cookie1000");
    if(totalCookies>=10000&&achievements.indexOf("cookie10000")<0)achievements.push("cookie10000");
    var tot=0;for(var i=0;i<upgrades.length;i++)tot+=upgrades[i].owned;
    if(tot>=1&&achievements.indexOf("firstUp")<0)achievements.push("firstUp");
  }
  function updateUI(){
    $("cookieCount").textContent=Math.floor(cookies);
    $("cookieCps").textContent=cps.toFixed(1);
    $("cookieClicks").textContent=totalClicks;$("cookieHigh").textContent=Math.max(Math.floor(totalCookies),getHighScore());
    for(var i=0;i<upgrades.length;i++){
      var btn=$("up_"+i);if(btn){
        var up=upgrades[i],cost=getCost(up),maxed=up.max&&up.owned>=up.max;
        btn.textContent=up.name+(up.owned>0?"("+up.owned+")":"")+" - "+(maxed?"已满":cost+"饼");
        btn.disabled=maxed||cookies<cost;btn.style.opacity=(maxed||cookies<cost)?"0.5":"1";
      }
    }
    drawCookie();
  }
  $("gameBody").innerHTML='<div style="text-align:center;margin-bottom:4px;">'
    +'<span id="cookieCount" style="font-size:22px;font-weight:bold;">0</span> 饼干 | '
    +'<span id="cookieCps">0</span>/秒 | 点击<span id="cookieClicks">0</span>次 | 最高:<span id="cookieHigh">0</span></div>'
    +'<canvas id="cookieCanvas" width="420" height="280" style="border:2px solid #000;cursor:pointer;"></canvas>';
  var uh='<button class="btn" id="cookieReset" style="width:100%;margin:2px 0;font-size:15px;padding:10px;">重置游戏</button><div style="max-height:160px;overflow-y:auto;">';
  for(var i=0;i<upgrades.length;i++)uh+='<button class="btn" id="up_'+i+'" style="width:100%;margin:2px 0;font-size:15px;padding:10px;text-align:left;"></button>';
  uh+='</div>';
  $("gameControls").innerHTML=uh;
  for(var i=0;i<upgrades.length;i++)$("up_"+i).onclick=(function(idx){return function(){buyUp(idx);};})(i);
  $("cookieReset").onclick=function(){
    showModal("重置游戏","确定清空所有饼干和升级吗？","确定重置",function(){
      try{localStorage.removeItem("kg_cookie");localStorage.removeItem("kg_cookie_high");}catch(e){}
      cookies=0;totalClicks=0;totalCookies=0;cps=0;clickPower=1;
      for(var i=0;i<upgrades.length;i++)upgrades[i].owned=0;
      saveCookie();updateUI();
    });
  };
  $("cookieCanvas").onclick=function(e){if(!clickBonus(e))clickCookie(e);};
  timer=setInterval(function(){
    if(cps>0){cookies+=cps/5;totalCookies+=cps/5;saveCookie();checkHighScore();updateUI();}
    if(floatTexts.length>0)drawCookie();
  },200);
  bonusTimer=setInterval(function(){if(Math.random()<0.2&&!bonusActive)spawnBonus();},12000);
  loadCookie();checkHighScore();updateUI();
  GAME_CLEANUPS.cookie=function(){saveCookie();checkHighScore();if(timer)clearInterval(timer);if(bonusTimer)clearInterval(bonusTimer);};
};

/* ==================== 20. 打地鼠 ==================== */
GAME_INITS.whack = function(){
  var score=0,timeLeft=60,gameOver=false;
  var timer=null,spawnTimer=null;
  var holes=[],hammers=[],effects=[];
  var CW=420,CH=360,COLS=3,ROWS=3,HW=120,HH=100;
  var sx=(CW-COLS*HW)/2,sy=25;
  for(var r=0;r<ROWS;r++)for(var c=0;c<COLS;c++)
    holes.push({x:sx+c*HW,y:sy+r*HH,state:"empty",prog:0,type:"mole",dt:null});
  function holeAt(px,py){
    for(var i=0;i<holes.length;i++){
      var h=holes[i];
      if(px>=h.x&&px<=h.x+HW&&py>=h.y&&py<=h.y+HH)return i;
    }
    return -1;
  }
  function draw(){
    var cv=$("whackCanvas");if(!cv)return;var ctx=cv.getContext("2d");
    ctx.fillStyle="#fff";ctx.fillRect(0,0,CW,CH);
    // 草地
    ctx.strokeStyle="#000";ctx.lineWidth=1;
    for(var gx=0;gx<CW;gx+=16){var gh=2+((gx*13)%4);ctx.beginPath();ctx.moveTo(gx,CH);ctx.lineTo(gx+3,CH-gh);ctx.stroke();}
    for(var i=0;i<holes.length;i++){
      var h=holes[i],cx=h.x+HW/2,cy=h.y+HH/2+16;
      // 洞（深色椭圆）
      ctx.fillStyle="#000";
      ctx.save();ctx.translate(cx,cy+12);ctx.scale(1,0.3);ctx.beginPath();ctx.arc(0,0,HW/2-8,0,Math.PI*2);ctx.fill();ctx.restore();
      ctx.fillStyle="#111";
      ctx.save();ctx.translate(cx,cy+12);ctx.scale(1,0.26);ctx.beginPath();ctx.arc(0,0,HW/2-14,0,Math.PI*2);ctx.fill();ctx.restore();
      // 地鼠
      if(h.state!=="empty"&&h.prog>0){
        var p=h.prog,mh=48*p,my=cy+12-mh;
        if(h.type==="bomb"){
          ctx.fillStyle="#000";ctx.beginPath();ctx.arc(cx,my+10,18,0,Math.PI*2);ctx.fill();
          ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(cx-5,my+5,4,0,Math.PI*2);ctx.fill();
          ctx.strokeStyle="#000";ctx.lineWidth=2.5;
          ctx.beginPath();ctx.moveTo(cx,my-6);ctx.quadraticCurveTo(cx+9,my-13,cx+7,my-20);ctx.stroke();
          ctx.fillStyle="#000";ctx.beginPath();ctx.arc(cx+7,my-22,3.5,0,Math.PI*2);ctx.fill();
          ctx.fillStyle="#fff";ctx.font="bold 16px monospace";ctx.textAlign="center";ctx.fillText("!",cx,my+16);ctx.textAlign="left";
        }else{
          // 身体
          ctx.fillStyle="#000";ctx.fillRect(cx-18,my+10,36,mh);
          // 头
          ctx.beginPath();ctx.arc(cx,my+10,21,0,Math.PI*2);ctx.fill();
          ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(cx,my+10,17,0,Math.PI*2);ctx.fill();
          // 耳朵
          ctx.fillStyle="#000";ctx.beginPath();ctx.arc(cx-18,my-2,6,0,Math.PI*2);ctx.fill();
          ctx.beginPath();ctx.arc(cx+18,my-2,6,0,Math.PI*2);ctx.fill();
          ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(cx-18,my-2,3,0,Math.PI*2);ctx.fill();
          ctx.beginPath();ctx.arc(cx+18,my-2,3,0,Math.PI*2);ctx.fill();
          // 眼睛
          if(h.state==="hit"){
            ctx.strokeStyle="#000";ctx.lineWidth=2.5;
            ctx.beginPath();ctx.moveTo(cx-10,my+4);ctx.lineTo(cx-4,my+10);ctx.stroke();
            ctx.beginPath();ctx.moveTo(cx-4,my+4);ctx.lineTo(cx-10,my+10);ctx.stroke();
            ctx.beginPath();ctx.moveTo(cx+4,my+4);ctx.lineTo(cx+10,my+10);ctx.stroke();
            ctx.beginPath();ctx.moveTo(cx+10,my+4);ctx.lineTo(cx+4,my+10);ctx.stroke();
          }else{
            ctx.fillStyle="#000";
            ctx.beginPath();ctx.arc(cx-7,my+6,4,0,Math.PI*2);ctx.fill();
            ctx.beginPath();ctx.arc(cx+7,my+6,4,0,Math.PI*2);ctx.fill();
            ctx.fillStyle="#fff";
            ctx.beginPath();ctx.arc(cx-6,my+5,1.5,0,Math.PI*2);ctx.fill();
            ctx.beginPath();ctx.arc(cx+8,my+5,1.5,0,Math.PI*2);ctx.fill();
          }
          // 鼻子
          ctx.fillStyle="#000";ctx.beginPath();ctx.arc(cx,my+13,4,0,Math.PI*2);ctx.fill();
          // 嘴+牙齿
          ctx.strokeStyle="#000";ctx.lineWidth=1.5;
          ctx.beginPath();ctx.arc(cx,my+15,6,0.1,Math.PI-0.1);ctx.stroke();
          ctx.fillStyle="#fff";ctx.fillRect(cx-4,my+16,8,4);
          ctx.strokeStyle="#000";ctx.lineWidth=1;ctx.strokeRect(cx-4,my+16,8,4);
          ctx.beginPath();ctx.moveTo(cx,my+16);ctx.lineTo(cx,my+20);ctx.stroke();
          // 胡须
          ctx.strokeStyle="#000";ctx.lineWidth=1;
          ctx.beginPath();ctx.moveTo(cx-11,my+12);ctx.lineTo(cx-22,my+9);ctx.stroke();
          ctx.beginPath();ctx.moveTo(cx-11,my+15);ctx.lineTo(cx-22,my+16);ctx.stroke();
          ctx.beginPath();ctx.moveTo(cx+11,my+12);ctx.lineTo(cx+22,my+9);ctx.stroke();
          ctx.beginPath();ctx.moveTo(cx+11,my+15);ctx.lineTo(cx+22,my+16);ctx.stroke();
          if(h.type==="gold"){
            ctx.fillStyle="#000";ctx.font="bold 18px monospace";ctx.textAlign="center";ctx.fillText("★",cx,my-12);ctx.textAlign="left";
          }
        }
      }
    }
    // 锤子
    for(var hi=hammers.length-1;hi>=0;hi--){
      var hm=hammers[hi];
      ctx.save();ctx.translate(hm.x,hm.y);
      if(hm.frame<6){
        // 落下阶段：从上方旋转下来
        var t=hm.frame/6;
        ctx.rotate(-1.2+t*1.4);
        ctx.translate(0,-30*(1-t));
      }else{
        // 砸中阶段：稍微回弹
        ctx.rotate(0.2-(hm.frame-6)*0.05);
      }
      // 木柄
      ctx.fillStyle="#000";ctx.fillRect(-3,-32,6,34);
      ctx.fillStyle="#fff";ctx.fillRect(-2,-31,4,32);
      // 铁头
      ctx.fillStyle="#000";ctx.fillRect(-15,-38,30,12);
      ctx.fillStyle="#fff";ctx.fillRect(-13,-36,26,8);
      ctx.fillStyle="#000";ctx.fillRect(-13,-36,5,8);
      ctx.restore();
      hm.frame++;
      if(hm.frame>14)hammers.splice(hi,1);
    }
    // 特效（星星+砰）
    for(var ei=effects.length-1;ei>=0;ei--){
      var ef=effects[ei];
      ctx.globalAlpha=ef.life/18;
      if(ef.type==="star"){
        ctx.fillStyle="#000";ctx.font="bold "+ef.size+"px monospace";ctx.textAlign="center";
        ctx.fillText("★",ef.x+ef.vx,ef.y+ef.vy);
      }else if(ef.type==="bang"){
        ctx.fillStyle="#000";ctx.font="bold 20px monospace";ctx.textAlign="center";
        ctx.fillText("砰!",ef.x,ef.y);
      }
      ctx.globalAlpha=1;ctx.textAlign="left";
      ef.y+=ef.vy;ef.vy+=0.15;ef.life--;
      if(ef.life<=0)effects.splice(ei,1);
    }
  }
  function retract(h,fast){
    if(h.dt)clearInterval(h.dt);
    var spd=fast?0.25:0.16;
    h.dt=setInterval(function(){
      h.prog-=spd;if(h.prog<=0){h.prog=0;h.state="empty";clearInterval(h.dt);h.dt=null;}
      draw();
    },40);
  }
  function spawn(){
    if(gameOver)return;
    var emp=[];for(var i=0;i<holes.length;i++)if(holes[i].state==="empty")emp.push(i);
    if(emp.length===0)return;
    var h=holes[emp[Math.floor(Math.random()*emp.length)]];
    var roll=Math.random();
    h.type=roll<0.15?"gold":(roll<0.25?"bomb":"mole");
    h.state="active";h.prog=0;
    if(h.dt)clearInterval(h.dt);
    h.dt=setInterval(function(){
      h.prog+=0.15;
      if(h.prog>=1){h.prog=1;clearInterval(h.dt);h.dt=null;
        setTimeout(function(){if(h.state==="active")retract(h,false);},900+Math.random()*500);
      }
      draw();
    },45);
  }
  function click(e){
    if(gameOver)return;
    var cv=$("whackCanvas"),rect=cv.getBoundingClientRect();
    var px=(e.clientX-rect.left)*(CW/rect.width),py=(e.clientY-rect.top)*(CH/rect.height);
    var idx=holeAt(px,py);
    if(idx<0)return;
    var h=holes[idx];
    if(h.state!=="active"||h.prog<0.3)return;
    // 命中！
    var cx=h.x+HW/2,headY=h.y+HH/2+16-48*h.prog+10;
    h.state="hit";
    // 锤子砸在头上
    hammers.push({x:cx,y:headY,frame:0});
    // 特效
    effects.push({type:"bang",x:cx,y:headY-15,life:18,vx:0,vy:0,size:0});
    for(var s=0;s<5;s++){
      effects.push({type:"star",x:cx+(Math.random()-0.5)*30,y:headY-10,
        vx:(Math.random()-0.5)*4,vy:-2-Math.random()*3,life:15+Math.floor(Math.random()*8),size:12+Math.floor(Math.random()*8)});
    }
    if(h.type==="mole")score+=1;
    else if(h.type==="gold")score+=3;
    else{score-=2;if(score<0)score=0;}
    setTimeout(function(){retract(h,true);},150);
    updateUI();draw();
  }
  function updateUI(){$("gameScore").textContent="得分:"+score+"    时间:"+timeLeft+"秒";}
  function endGame(){
    gameOver=true;if(timer)clearInterval(timer);if(spawnTimer)clearInterval(spawnTimer);
    for(var i=0;i<holes.length;i++)if(holes[i].dt)clearInterval(holes[i].dt);
    var high=0;try{high=parseInt(localStorage.getItem("kg_whack_high")||"0");}catch(e){}
    if(score>high)try{localStorage.setItem("kg_whack_high",score);}catch(e){}
    showModal("时间到!","得分:"+score+"\n最高分:"+Math.max(score,high),"再来一局",function(){
      score=0;timeLeft=60;gameOver=false;hammers=[];effects=[];
      for(var i=0;i<holes.length;i++){holes[i].state="empty";holes[i].prog=0;}
      start();
    });
  }
  function start(){
    updateUI();draw();
    timer=setInterval(function(){timeLeft--;updateUI();if(timeLeft<=0)endGame();},1000);
    spawnTimer=setInterval(function(){if(!gameOver)spawn();},580);
  }
  $("gameBody").innerHTML='<canvas id="whackCanvas" width="'+CW+'" height="'+CH+'" style="border:2px solid #000;cursor:pointer;"></canvas>';
  $("gameControls").innerHTML="";
  $("whackCanvas").onclick=click;
  start();
  GAME_CLEANUPS.whack=function(){if(timer)clearInterval(timer);if(spawnTimer)clearInterval(spawnTimer);
    for(var i=0;i<holes.length;i++)if(holes[i].dt)clearInterval(holes[i].dt);};
};

/* ==================== 21. 黄金矿工 ==================== */
GAME_INITS.goldminer = function(){
  var CW=420,CH=390;
  var level=1,score=0,timeLeft=60,target=650;
  var state="swing";
  var angle=0,adir=1,hlen=40,hspeed=0;
  var MIN_LEN=40;
  var caught=null,items=[];
  var timer=null,anim=null;
  var MX=CW/2,MY=52;
  var PIVOT_Y=MY+26;
  var TYPES=[
    {t:"gl",name:"大金块",val:500,w:3,r:26},
    {t:"gm",name:"中金块",val:200,w:2,r:19},
    {t:"gs",name:"小金块",val:50,w:1,r:13},
    {t:"rl",name:"大石头",val:20,w:4,r:23},
    {t:"rs",name:"小石头",val:10,w:2,r:14},
    {t:"dia",name:"钻石",val:600,w:1,r:12},
    {t:"bag",name:"袋子",val:0,w:2,r:16}
  ];
  function genLevel(){
    items=[];var n=10+level,placed=0,guard=0;
    while(placed<n&&guard<500){guard++;
      var tp=TYPES[Math.floor(Math.random()*TYPES.length)];
      var x=30+Math.random()*(CW-60),y=125+Math.random()*(CH-160);
      var ok=true;
      for(var i=0;i<items.length;i++){
        var dx=x-items[i].x,dy=y-items[i].y;
        if(dx*dx+dy*dy<(tp.r+items[i].r+6)*(tp.r+items[i].r+6)){ok=false;break;}
      }
      if(ok){var mult=1+(level-1)*0.25;var v=Math.floor(tp.val*mult);if(tp.t==="bag")v=Math.floor((100+Math.floor(Math.random()*400))*mult);
        items.push({x:x,y:y,t:tp.t,name:tp.name,val:v,w:tp.w,r:tp.r});placed++;}
    }
    target=650+(level-1)*400;timeLeft=60;
  }
  function drawGold(ctx,it,x,y){
    var r=it.r;
    ctx.fillStyle="#000";ctx.beginPath();
    ctx.moveTo(x-r,y-r*0.55);ctx.lineTo(x-r*0.3,y-r*0.8);
    ctx.lineTo(x+r*0.7,y-r*0.65);ctx.lineTo(x+r,y-r*0.1);
    ctx.lineTo(x+r*0.85,y+r*0.5);ctx.lineTo(x+r*0.2,y+r*0.85);
    ctx.lineTo(x-r*0.6,y+r*0.7);ctx.lineTo(x-r*0.9,y+r*0.1);
    ctx.closePath();ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();
    ctx.moveTo(x-r*0.55,y-r*0.3);ctx.lineTo(x-r*0.05,y-r*0.5);
    ctx.lineTo(x+r*0.4,y-r*0.35);ctx.lineTo(x+r*0.5,y+r*0.1);
    ctx.lineTo(x+r*0.3,y+r*0.45);ctx.lineTo(x-r*0.1,y+r*0.5);
    ctx.lineTo(x-r*0.45,y+r*0.25);
    ctx.closePath();ctx.fill();
    ctx.fillStyle="#000";ctx.fillRect(x-r*0.4,y-r*0.35,r*0.45,2);
    ctx.fillRect(x-r*0.25,y+r*0.3,r*0.35,2);
  }
  function drawRock(ctx,it,x,y){
    var r=it.r;
    ctx.fillStyle="#000";ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(x,y,r-3,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#000";
    ctx.beginPath();ctx.arc(x-r*0.35,y-r*0.25,2.5,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(x+r*0.25,y+r*0.1,2,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(x-r*0.1,y+r*0.35,1.8,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(x-r*0.3,y-r*0.3,3,0,Math.PI*2);ctx.fill();
  }
  function drawDiamond(ctx,it,x,y){
    var r=it.r;
    ctx.fillStyle="#000";ctx.beginPath();
    ctx.moveTo(x,y-r);ctx.lineTo(x+r,y-r*0.1);ctx.lineTo(x,y+r);ctx.lineTo(x-r,y-r*0.1);
    ctx.closePath();ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();
    ctx.moveTo(x,y-r*0.6);ctx.lineTo(x+r*0.6,y-r*0.05);ctx.lineTo(x,y+r*0.6);ctx.lineTo(x-r*0.6,y-r*0.05);
    ctx.closePath();ctx.fill();
    ctx.fillStyle="#000";ctx.beginPath();
    ctx.moveTo(x,y-r*0.6);ctx.lineTo(x+r*0.25,y-r*0.25);ctx.lineTo(x-r*0.25,y-r*0.25);
    ctx.closePath();ctx.fill();
    ctx.strokeStyle="#000";ctx.lineWidth=1.5;
    ctx.beginPath();ctx.moveTo(x-r*0.6,y-r*0.05);ctx.lineTo(x+r*0.6,y-r*0.05);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x-r*0.25,y+r*0.2);ctx.lineTo(x,y+r*0.6);ctx.lineTo(x+r*0.25,y+r*0.2);ctx.stroke();
    ctx.fillStyle="#fff";ctx.fillRect(x-r*0.2,y-r*0.2,3,7);
  }
  function drawBag(ctx,it,x,y){
    var r=it.r;
    ctx.fillStyle="#000";ctx.beginPath();
    ctx.moveTo(x-r*0.75,y-r*0.4);ctx.lineTo(x+r*0.75,y-r*0.4);
    ctx.lineTo(x+r*0.95,y+r*0.75);ctx.quadraticCurveTo(x,y+r*0.95,x-r*0.95,y+r*0.75);
    ctx.closePath();ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();
    ctx.moveTo(x-r*0.55,y-r*0.25);ctx.lineTo(x+r*0.55,y-r*0.25);
    ctx.lineTo(x+r*0.7,y+r*0.6);ctx.quadraticCurveTo(x,y+r*0.78,x-r*0.7,y+r*0.6);
    ctx.closePath();ctx.fill();
    ctx.strokeStyle="#000";ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(x-r*0.4,y-r*0.1);ctx.lineTo(x-r*0.45,y+r*0.5);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x+r*0.4,y-r*0.1);ctx.lineTo(x+r*0.45,y+r*0.5);ctx.stroke();
    ctx.strokeStyle="#000";ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(x-r*0.55,y-r*0.4);ctx.quadraticCurveTo(x-r*0.4,y-r*0.7,x-r*0.2,y-r*0.6);ctx.stroke();
    ctx.beginPath();ctx.moveTo(x+r*0.55,y-r*0.4);ctx.quadraticCurveTo(x+r*0.4,y-r*0.7,x+r*0.2,y-r*0.6);ctx.stroke();
    ctx.fillStyle="#000";ctx.beginPath();ctx.arc(x,y-r*0.55,4,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#000";ctx.font="bold 14px monospace";ctx.textAlign="center";ctx.fillText("?",x,y+r*0.25);ctx.textAlign="left";
  }
  function drawItem(ctx,it,x,y){
    if(it.t==="gl"||it.t==="gm"||it.t==="gs")drawGold(ctx,it,x,y);
    else if(it.t==="rl"||it.t==="rs")drawRock(ctx,it,x,y);
    else if(it.t==="dia")drawDiamond(ctx,it,x,y);
    else if(it.t==="bag")drawBag(ctx,it,x,y);
  }
  function drawMiner(ctx){
    // === 矿车 ===
    // 车身
    ctx.fillStyle="#000";
    ctx.beginPath();
    ctx.moveTo(MX-28,MY+22);ctx.lineTo(MX+28,MY+22);
    ctx.lineTo(MX+26,MY+38);ctx.lineTo(MX-26,MY+38);
    ctx.closePath();ctx.fill();
    ctx.fillStyle="#fff";
    ctx.beginPath();
    ctx.moveTo(MX-25,MY+24);ctx.lineTo(MX+25,MY+24);
    ctx.lineTo(MX+23,MY+36);ctx.lineTo(MX-23,MY+36);
    ctx.closePath();ctx.fill();
    // 车身上的木板纹
    ctx.strokeStyle="#000";ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(MX-8,MY+24);ctx.lineTo(MX-9,MY+36);ctx.stroke();
    ctx.beginPath();ctx.moveTo(MX+8,MY+24);ctx.lineTo(MX+9,MY+36);ctx.stroke();
    // 车轮（两个大轮子）
    ctx.fillStyle="#000";
    ctx.beginPath();ctx.arc(MX-17,MY+40,9,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(MX+17,MY+40,9,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";
    ctx.beginPath();ctx.arc(MX-17,MY+40,5,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(MX+17,MY+40,5,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#000";
    ctx.beginPath();ctx.arc(MX-17,MY+40,2,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(MX+17,MY+40,2,0,Math.PI*2);ctx.fill();
    // 轮辐
    ctx.strokeStyle="#000";ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(MX-17,MY+35);ctx.lineTo(MX-17,MY+45);ctx.stroke();
    ctx.beginPath();ctx.moveTo(MX-22,MY+40);ctx.lineTo(MX-12,MY+40);ctx.stroke();
    ctx.beginPath();ctx.moveTo(MX+17,MY+35);ctx.lineTo(MX+17,MY+45);ctx.stroke();
    ctx.beginPath();ctx.moveTo(MX+12,MY+40);ctx.lineTo(MX+22,MY+40);ctx.stroke();
    // === 矿工身体（坐在矿车里，前倾） ===
    // 腿（弯曲在车内）
    ctx.fillStyle="#000";
    ctx.beginPath();ctx.moveTo(MX-12,MY+12);ctx.lineTo(MX-16,MY+22);ctx.lineTo(MX-8,MY+22);ctx.lineTo(MX-6,MY+14);ctx.closePath();ctx.fill();
    ctx.beginPath();ctx.moveTo(MX+12,MY+12);ctx.lineTo(MX+16,MY+22);ctx.lineTo(MX+8,MY+22);ctx.lineTo(MX+6,MY+14);ctx.closePath();ctx.fill();
    // 躯干（衬衫+背带裤）
    ctx.fillStyle="#000";
    ctx.beginPath();
    ctx.moveTo(MX-16,MY-4);ctx.lineTo(MX+16,MY-4);
    ctx.lineTo(MX+18,MY+16);ctx.lineTo(MX-18,MY+16);
    ctx.closePath();ctx.fill();
    // 衬衫（白色，在背带之间）
    ctx.fillStyle="#fff";
    ctx.beginPath();
    ctx.moveTo(MX-13,MY-2);ctx.lineTo(MX+13,MY-2);
    ctx.lineTo(MX+15,MY+14);ctx.lineTo(MX-15,MY+14);
    ctx.closePath();ctx.fill();
    // 背带
    ctx.fillStyle="#000";ctx.fillRect(MX-9,MY-4,5,18);
    ctx.fillRect(MX+4,MY-4,5,18);
    // 背带扣子
    ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(MX-6,MY+5,2,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(MX+6,MY+5,2,0,Math.PI*2);ctx.fill();
    // 胸前口袋
    ctx.strokeStyle="#000";ctx.lineWidth=1.5;
    ctx.strokeRect(MX-5,MY+7,10,6);
    // === 头（前倾） ===
    ctx.fillStyle="#000";ctx.beginPath();ctx.arc(MX,MY-12,14,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(MX,MY-12,11,0,Math.PI*2);ctx.fill();
    // 安全帽（黄色=白底黑边）
    ctx.fillStyle="#000";
    ctx.beginPath();ctx.arc(MX,MY-17,13,Math.PI*1.05,Math.PI*1.95);ctx.fill();
    ctx.fillRect(MX-15,MY-19,30,5);
    ctx.fillStyle="#fff";
    ctx.beginPath();ctx.arc(MX,MY-17,10,Math.PI*1.05,Math.PI*1.95);ctx.fill();
    ctx.fillRect(MX-12,MY-18,24,2);
    // 帽顶凸起
    ctx.fillStyle="#000";
    ctx.beginPath();ctx.arc(MX,MY-24,5,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";
    ctx.beginPath();ctx.arc(MX,MY-24,3,0,Math.PI*2);ctx.fill();
    // 头灯光束
    ctx.fillStyle="#000";
    ctx.beginPath();ctx.moveTo(MX,MY-27);ctx.lineTo(MX-3,MY-32);ctx.lineTo(MX+3,MY-32);ctx.closePath();ctx.fill();
    // 眼睛（向前看，带瞳孔高光）
    ctx.fillStyle="#000";
    ctx.beginPath();ctx.arc(MX-5,MY-12,2.5,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(MX+5,MY-12,2.5,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";
    ctx.beginPath();ctx.arc(MX-4,MY-13,1,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(MX+6,MY-13,1,0,Math.PI*2);ctx.fill();
    // 眉毛（浓密）
    ctx.strokeStyle="#000";ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(MX-9,MY-16);ctx.lineTo(MX-2,MY-15);ctx.stroke();
    ctx.beginPath();ctx.moveTo(MX+2,MY-15);ctx.lineTo(MX+9,MY-16);ctx.stroke();
    // 大鼻子
    ctx.fillStyle="#000";ctx.beginPath();ctx.arc(MX,MY-8,3.5,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(MX-1,MY-9,1.2,0,Math.PI*2);ctx.fill();
    // 白色大胡子（浓密，带纹理）
    ctx.fillStyle="#000";
    ctx.beginPath();
    ctx.moveTo(MX-12,MY-7);
    ctx.quadraticCurveTo(MX-14,MY+2,MX-10,MY+5);
    ctx.lineTo(MX-5,MY+3);
    ctx.quadraticCurveTo(MX,MY+6,MX+5,MY+3);
    ctx.lineTo(MX+10,MY+5);
    ctx.quadraticCurveTo(MX+14,MY+2,MX+12,MY-7);
    ctx.closePath();ctx.fill();
    ctx.fillStyle="#fff";
    ctx.beginPath();
    ctx.moveTo(MX-9,MY-6);
    ctx.quadraticCurveTo(MX-11,MY+1,MX-8,MY+3);
    ctx.lineTo(MX-4,MY+2);
    ctx.quadraticCurveTo(MX,MY+4,MX+4,MY+2);
    ctx.lineTo(MX+8,MY+3);
    ctx.quadraticCurveTo(MX+11,MY+1,MX+9,MY-6);
    ctx.closePath();ctx.fill();
    // 胡子纹理线
    ctx.strokeStyle="#000";ctx.lineWidth=1;
    ctx.beginPath();ctx.moveTo(MX-6,MY-5);ctx.lineTo(MX-7,MY+2);ctx.stroke();
    ctx.beginPath();ctx.moveTo(MX,MY-6);ctx.lineTo(MX,MY+3);ctx.stroke();
    ctx.beginPath();ctx.moveTo(MX+6,MY-5);ctx.lineTo(MX+7,MY+2);ctx.stroke();
    // 嘴（在胡子上方，微笑）
    ctx.strokeStyle="#000";ctx.lineWidth=1.5;
    ctx.beginPath();ctx.arc(MX,MY-8,3,0.2,Math.PI-0.2);ctx.stroke();
    // === 手臂 ===
    // 右臂前伸（抓绳子控制器）
    ctx.fillStyle="#000";
    ctx.beginPath();
    ctx.moveTo(MX+14,MY);ctx.lineTo(MX+27,MY-4);
    ctx.lineTo(MX+29,MY+2);ctx.lineTo(MX+16,MY+6);
    ctx.closePath();ctx.fill();
    // 右手
    ctx.fillStyle="#000";ctx.beginPath();ctx.arc(MX+29,MY-1,5,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(MX+29,MY-1,3,0,Math.PI*2);ctx.fill();
    // 控制器（小方块）
    ctx.fillStyle="#000";ctx.fillRect(MX+33,MY-5,8,8);
    ctx.fillStyle="#fff";ctx.fillRect(MX+35,MY-3,4,4);
    // 左臂弯曲放膝盖
    ctx.fillStyle="#000";
    ctx.beginPath();
    ctx.moveTo(MX-14,MY);ctx.lineTo(MX-22,MY+4);
    ctx.lineTo(MX-20,MY+10);ctx.lineTo(MX-12,MY+6);
    ctx.closePath();ctx.fill();
    ctx.fillStyle="#000";ctx.beginPath();ctx.arc(MX-21,MY+8,4,0,Math.PI*2);ctx.fill();
  }
  function drawHook(ctx,hx,hy){
    // 绳子
    ctx.strokeStyle="#000";ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(MX,PIVOT_Y);ctx.lineTo(hx,hy);ctx.stroke();
    // 转轴环
    ctx.fillStyle="#000";ctx.beginPath();ctx.arc(hx,hy,5,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(hx,hy,2.5,0,Math.PI*2);ctx.fill();
    // U形钩身
    ctx.strokeStyle="#000";ctx.lineWidth=3.5;
    ctx.beginPath();
    ctx.moveTo(hx-8,hy+4);
    ctx.quadraticCurveTo(hx-8,hy+18,hx,hy+18);
    ctx.quadraticCurveTo(hx+8,hy+18,hx+8,hy+4);
    ctx.stroke();
    // 左爪尖
    ctx.fillStyle="#000";
    ctx.beginPath();ctx.moveTo(hx-8,hy+4);ctx.lineTo(hx-13,hy+9);ctx.lineTo(hx-6,hy+8);ctx.closePath();ctx.fill();
    // 右爪尖
    ctx.beginPath();ctx.moveTo(hx+8,hy+4);ctx.lineTo(hx+13,hy+9);ctx.lineTo(hx+6,hy+8);ctx.closePath();ctx.fill();
  }
  function draw(){
    var cv=$("minerCanvas");if(!cv)return;var ctx=cv.getContext("2d");
    ctx.fillStyle="#fff";ctx.fillRect(0,0,CW,CH);
    // 地面线
    ctx.fillStyle="#000";ctx.fillRect(0,95,CW,3);
    // 草地
    ctx.lineWidth=1;
    for(var gx=0;gx<CW;gx+=11){ctx.beginPath();ctx.moveTo(gx,95);ctx.lineTo(gx+4,101);ctx.stroke();}
    // 地下纹理
    ctx.fillStyle="#000";
    for(var dx=20;dx<CW;dx+=32)for(var dy=120;dy<CH;dy+=28){
      if(((dx+dy)*7)%3===0)ctx.fillRect(dx,dy,2,2);
    }
    // 物品
    for(var i=0;i<items.length;i++)if(items[i]!==caught)drawItem(ctx,items[i],items[i].x,items[i].y);
    // 抓到的物品跟钩子走
    if(caught&&state==="pull"){
      var hx2=MX+Math.sin(angle)*hlen,hy2=PIVOT_Y+Math.cos(angle)*hlen;
      drawItem(ctx,caught,hx2,hy2+caught.r+10);
    }
    // 矿工
    drawMiner(ctx);
    // 钩子（始终在矿工下方）
    var hx=MX+Math.sin(angle)*hlen,hy=PIVOT_Y+Math.cos(angle)*hlen;
    drawHook(ctx,hx,hy);
  }
  function shoot(){
    if(state!=="swing")return;
    state="shoot";hspeed=7;
  }
  function update(){
    if(state==="swing"){
      angle+=0.055*adir;
      if(angle>1.35)adir=-1;
      if(angle<-1.35)adir=1;
    }else if(state==="shoot"){
      hlen+=hspeed;
      var hx=MX+Math.sin(angle)*hlen,hy=PIVOT_Y+Math.cos(angle)*hlen;
      for(var i=0;i<items.length;i++){
        var it=items[i],dx=hx-it.x,dy=hy-it.y;
        if(dx*dx+dy*dy<(it.r+8)*(it.r+8)){
          caught=it;state="pull";hspeed=7/Math.max(1,it.w*0.6);break;
        }
      }
      if(hlen>310||hx<5||hx>CW-5||hy>CH-5){state="pull";hspeed=7;}
    }else if(state==="pull"){
      hlen-=hspeed;
      if(hlen<=MIN_LEN){hlen=MIN_LEN;
        if(caught){score+=caught.val;
          var idx=items.indexOf(caught);if(idx>=0)items.splice(idx,1);caught=null;}
        state="swing";updateUI();
        if(score>=target)levelEnd();
      }
    }
    draw();
  }
  function levelEnd(){
    state="levelend";if(timer)clearInterval(timer);
    showModal("第"+level+"关通过!","得分:"+score+"  目标:"+target,"下一关",function(){
      level++;score=0;genLevel();state="swing";angle=0;hlen=MIN_LEN;start();
    });
  }
  function over(){
    state="over";if(timer)clearInterval(timer);if(anim)clearInterval(anim);
    var high=0;try{high=parseInt(localStorage.getItem("kg_miner_high")||"0");}catch(e){}
    if(score>high)try{localStorage.setItem("kg_miner_high",score);}catch(e){}
    showModal("游戏结束","到达第"+level+"关\n得分:"+score+"\n最高分:"+Math.max(score,high),"再来一局",function(){
      level=1;score=0;genLevel();state="swing";angle=0;hlen=MIN_LEN;start();
    });
  }
  function updateUI(){$("gameScore").textContent="第"+level+"关  "+score+"/"+target+"  时间:"+timeLeft+"秒";}
  function start(){
    updateUI();draw();
    timer=setInterval(function(){timeLeft--;updateUI();if(timeLeft<=0&&state!=="levelend")over();},1000);
    anim=setInterval(update,50);
  }
  $("gameBody").innerHTML='<canvas id="minerCanvas" width="'+CW+'" height="'+CH+'" style="border:2px solid #000;cursor:pointer;"></canvas>';
  $("gameControls").innerHTML="";
  $("minerCanvas").onclick=function(){shoot();};
  genLevel();angle=0;hlen=MIN_LEN;start();
  GAME_CLEANUPS.goldminer=function(){if(timer)clearInterval(timer);if(anim)clearInterval(anim);};
};

/* ==================== 启动 ==================== */
renderMenu();

// 暴露到全局，供HTML onclick调用
window.exitApp = exitApp;

/* ==================== 22. 接元宝（滑动操作） ==================== */
GAME_INITS.catchgold = function(){
  var CW=560,CH=560;
  var score=0,lives=3,over=false;
  var basket={x:CW/2,y:CH-40,w:100,h:32};
  var items=[];
  var spawnTimer=0,spawnInterval=20;
  var baseSpeed=2.5;
  var anim=null;
  var dragging=false;

  function getHigh(){try{return parseInt(localStorage.getItem("kg_catch_high")||"0");}catch(e){return 0;}}
  function saveHigh(){try{if(score>getHigh())localStorage.setItem("kg_catch_high",score);}catch(e){}}

  function spawn(){
    var r=Math.random();
    var type,val,spd;
    if(r<0.55){type="gold";val=10;spd=baseSpeed+Math.random()*1.5;}
    else if(r<0.75){type="bigGold";val=30;spd=baseSpeed+Math.random()*1;}
    else if(r<0.88){type="diamond";val=50;spd=baseSpeed+0.5+Math.random()*1;}
    else{type="bomb";val=0;spd=baseSpeed+1+Math.random()*2;}
    items.push({x:20+Math.random()*(CW-40),y:-20,type:type,val:val,spd:spd,r:16});
  }

  function drawGold(ctx,x,y,r){
    // 金元宝：船形+中间凸起
    ctx.fillStyle="#000";
    ctx.beginPath();
    ctx.moveTo(x-r,y+r*0.3);
    ctx.quadraticCurveTo(x-r*0.8,y+r*0.7,x,y+r*0.7);
    ctx.quadraticCurveTo(x+r*0.8,y+r*0.7,x+r,y+r*0.3);
    ctx.lineTo(x+r*0.7,y-r*0.1);
    ctx.quadraticCurveTo(x+r*0.5,y-r*0.5,x,y-r*0.5);
    ctx.quadraticCurveTo(x-r*0.5,y-r*0.5,x-r*0.7,y-r*0.1);
    ctx.closePath();ctx.fill();
    ctx.fillStyle="#fff";
    ctx.beginPath();
    ctx.moveTo(x-r*0.6,y+r*0.1);
    ctx.quadraticCurveTo(x-r*0.5,y+r*0.45,x,y+r*0.45);
    ctx.quadraticCurveTo(x+r*0.5,y+r*0.45,x+r*0.6,y+r*0.1);
    ctx.lineTo(x+r*0.4,y-r*0.05);
    ctx.quadraticCurveTo(x+r*0.3,y-r*0.3,x,y-r*0.3);
    ctx.quadraticCurveTo(x-r*0.3,y-r*0.3,x-r*0.4,y-r*0.05);
    ctx.closePath();ctx.fill();
    // 高光
    ctx.fillStyle="#000";ctx.fillRect(x-r*0.35,y-r*0.15,r*0.3,2);
  }

  function drawBigGold(ctx,x,y,r){
    drawGold(ctx,x,y,r*1.3);
    ctx.fillStyle="#000";ctx.font="bold 12px monospace";ctx.textAlign="center";
    ctx.fillText("30",x,y+r*0.35);ctx.textAlign="left";
  }

  function drawDiamond(ctx,x,y,r){
    ctx.fillStyle="#000";ctx.beginPath();
    ctx.moveTo(x,y-r);ctx.lineTo(x+r,y-r*0.1);ctx.lineTo(x,y+r);ctx.lineTo(x-r,y-r*0.1);
    ctx.closePath();ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();
    ctx.moveTo(x,y-r*0.55);ctx.lineTo(x+r*0.55,y-r*0.05);ctx.lineTo(x,y+r*0.55);ctx.lineTo(x-r*0.55,y-r*0.05);
    ctx.closePath();ctx.fill();
    ctx.strokeStyle="#000";ctx.lineWidth=1.5;
    ctx.beginPath();ctx.moveTo(x-r*0.55,y-r*0.05);ctx.lineTo(x+r*0.55,y-r*0.05);ctx.stroke();
    ctx.fillStyle="#fff";ctx.fillRect(x-r*0.15,y-r*0.2,3,6);
  }

  function drawBomb(ctx,x,y,r){
    // 炸弹：黑色圆球+引线+火花
    ctx.fillStyle="#000";ctx.beginPath();ctx.arc(x,y+r*0.1,r*0.85,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(x-r*0.25,y-r*0.1,r*0.2,0,Math.PI*2);ctx.fill();
    // 引线
    ctx.strokeStyle="#000";ctx.lineWidth=2.5;
    ctx.beginPath();ctx.moveTo(x+r*0.3,y-r*0.5);ctx.quadraticCurveTo(x+r*0.6,y-r*0.9,x+r*0.4,y-r*1.1);ctx.stroke();
    // 火花
    ctx.fillStyle="#000";
    ctx.beginPath();ctx.arc(x+r*0.4,y-r*1.15,4,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";
    ctx.beginPath();ctx.arc(x+r*0.4,y-r*1.15,2,0,Math.PI*2);ctx.fill();
  }

  function drawBasket(ctx){
    var bx=basket.x-basket.w/2, by=basket.y;
    // 篮子主体（梯形）
    ctx.fillStyle="#000";
    ctx.beginPath();
    ctx.moveTo(bx,by);ctx.lineTo(bx+basket.w,by);
    ctx.lineTo(bx+basket.w-8,by+basket.h);ctx.lineTo(bx+8,by+basket.h);
    ctx.closePath();ctx.fill();
    ctx.fillStyle="#fff";
    ctx.beginPath();
    ctx.moveTo(bx+3,by+3);ctx.lineTo(bx+basket.w-3,by+3);
    ctx.lineTo(bx+basket.w-9,by+basket.h-3);ctx.lineTo(bx+9,by+basket.h-3);
    ctx.closePath();ctx.fill();
    // 编织纹
    ctx.strokeStyle="#000";ctx.lineWidth=1;
    for(var i=1;i<4;i++){
      var yy=by+i*(basket.h/4);
      ctx.beginPath();ctx.moveTo(bx+4,yy);ctx.lineTo(bx+basket.w-4,yy);ctx.stroke();
    }
    for(var j=1;j<6;j++){
      var xx=bx+j*(basket.w/6);
      ctx.beginPath();ctx.moveTo(xx,by+2);ctx.lineTo(xx-2,by+basket.h-2);ctx.stroke();
    }
    // 篮子口沿
    ctx.fillStyle="#000";ctx.fillRect(bx-2,by-3,basket.w+4,5);
  }

  function drawLives(ctx){
    for(var i=0;i<3;i++){
      var hx=15+i*28, hy=18;
      if(i<lives){
        ctx.fillStyle="#000";
        ctx.beginPath();
        ctx.moveTo(hx,hy+6);
        ctx.bezierCurveTo(hx-14,hy-6,hx-8,hy-14,hx,hy-6);
        ctx.bezierCurveTo(hx+8,hy-14,hx+14,hy-6,hx,hy+6);
        ctx.fill();
      }else{
        ctx.strokeStyle="#999";ctx.lineWidth=2;
        ctx.beginPath();
        ctx.moveTo(hx,hy+6);
        ctx.bezierCurveTo(hx-14,hy-6,hx-8,hy-14,hx,hy-6);
        ctx.bezierCurveTo(hx+8,hy-14,hx+14,hy-6,hx,hy+6);
        ctx.stroke();
      }
    }
  }

  function draw(){
    var cv=$("catchCanvas");if(!cv)return;var ctx=cv.getContext("2d");
    ctx.fillStyle="#fff";ctx.fillRect(0,0,CW,CH);
    // 顶部装饰线
    ctx.fillStyle="#000";ctx.fillRect(0,32,CW,2);
    // 云朵
    ctx.fillStyle="#000";
    ctx.beginPath();ctx.arc(80,55,12,0,Math.PI*2);ctx.arc(95,50,14,0,Math.PI*2);ctx.arc(112,55,11,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(320,48,10,0,Math.PI*2);ctx.arc(335,44,13,0,Math.PI*2);ctx.arc(350,48,9,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";
    ctx.beginPath();ctx.arc(82,53,8,0,Math.PI*2);ctx.arc(96,49,10,0,Math.PI*2);ctx.arc(110,53,7,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(322,47,7,0,Math.PI*2);ctx.arc(335,43,9,0,Math.PI*2);ctx.arc(348,47,6,0,Math.PI*2);ctx.fill();
    // 掉落物
    for(var i=0;i<items.length;i++){
      var it=items[i];
      if(it.type==="gold")drawGold(ctx,it.x,it.y,it.r);
      else if(it.type==="bigGold")drawBigGold(ctx,it.x,it.y,it.r);
      else if(it.type==="diamond")drawDiamond(ctx,it.x,it.y,it.r);
      else if(it.type==="bomb")drawBomb(ctx,it.x,it.y,it.r);
    }
    // 篮子
    drawBasket(ctx);
    // 生命
    drawLives(ctx);
    // 分数
    ctx.fillStyle="#000";ctx.font="bold 20px monospace";ctx.textAlign="right";
    ctx.fillText("分数:"+score,CW-15,22);ctx.textAlign="left";
  }

  function update(){
    if(over)return;
    // 难度随分数增加
    var diff=1+Math.floor(score/100)*0.15;
    spawnTimer++;
    if(spawnTimer>=spawnInterval){
      spawnTimer=0;
      spawn();
      spawnInterval=Math.max(8,20-Math.floor(score/50)*1);
    }
    // 更新掉落物
    for(var i=items.length-1;i>=0;i--){
      var it=items[i];
      it.y+=it.spd*diff*2.5;
      // 检测是否被篮子接住
      if(it.y+it.r>=basket.y && it.y-it.r<=basket.y+basket.h){
        if(it.x>=basket.x-basket.w/2 && it.x<=basket.x+basket.w/2){
          if(it.type==="bomb"){
            lives--;
            items.splice(i,1);
            if(lives<=0){gameOver();}
          }else{
            score+=it.val;
            items.splice(i,1);
          }
          continue;
        }
      }
      // 掉出屏幕
      if(it.y>CH+20){items.splice(i,1);}
    }
    draw();
  }

  function gameOver(){
    over=true;
    if(anim)clearInterval(anim);
    saveHigh();
    showModal("游戏结束","得分:"+score+"\n最高分:"+getHigh(),"再来一局",function(){
      score=0;lives=3;over=false;items=[];spawnTimer=0;spawnInterval=50;
      basket.x=CW/2;catchRect=null;
      anim=setInterval(update,100);
      draw();
    });
  }

  var catchCv=null,catchRect=null;
  function moveBasket(clientX){
    if(!catchCv){catchCv=document.getElementById("catchCanvas");if(!catchCv)return;}
    if(!catchRect)catchRect=catchCv.getBoundingClientRect();
    var x=(clientX-catchRect.left)*(CW/catchRect.width);
    basket.x=Math.max(basket.w/2,Math.min(CW-basket.w/2,x));
    draw();
  }

  $("gameBody").innerHTML='<canvas id="catchCanvas" width="'+CW+'" height="'+CH+'" style="border:2px solid #000;cursor:pointer;"></canvas>';
  $("gameControls").innerHTML="";
  $("gameScore").textContent="滑动屏幕移动篮子  最高:"+getHigh();

  draw();

  var cv=document.getElementById("catchCanvas");
  if(cv){
    // 触屏滑动（属性绑定，兼容旧WebKit）
    cv.ontouchstart=function(e){if(e&&e.touches&&e.touches[0]){dragging=true;moveBasket(e.touches[0].clientX);}return false;};
    cv.ontouchmove=function(e){if(e&&e.touches&&e.touches[0]&&dragging){moveBasket(e.touches[0].clientX);}return false;};
    cv.ontouchend=function(e){dragging=false;return false;};
    // 鼠标拖动（PC测试）
    cv.onmousedown=function(e){dragging=true;if(e)moveBasket(e.clientX);};
    cv.onmousemove=function(e){if(dragging&&e)moveBasket(e.clientX);};
    cv.onmouseup=function(){dragging=false;};
    cv.onmouseleave=function(){dragging=false;};
  }

  anim=setInterval(update,100);
  GAME_CLEANUPS.catchgold=function(){if(anim)clearInterval(anim);};
};


window.backToMenu = backToMenu;

})();

