#!/bin/sh
# 游戏合集安装脚本

PKG="/mnt/us/kindle-games-package"
BASE="/mnt/us/kindle_games"
BIN="$BASE/bin"
WAF="$BASE/webview"
APP_ID="com.kindlegames.v1"
JOB="kindle-games"
CONF="/etc/upstart/${JOB}.conf"
INSTALL_LOG="$BASE/install.log"
VIEWER="/mnt/us/documents/游戏合集.sh"
APPREG=""

toast() { lipc-set-prop com.lab126.system toasterMessage "$1" >/dev/null 2>&1 || true; }
fail() { echo "$(date): ERROR: $1" >> "$INSTALL_LOG"; toast "安装失败: $1"; exit 1; }

mkdir -p "$BASE"
echo "$(date): 安装脚本启动, uid=$(id -u)" >> "$INSTALL_LOG"

# 检查权限和环境
[ "$(id -u)" -eq 0 ] || fail "需要 root 权限，请通过 ;log runme 或 KUAL 运行"
[ -x /usr/bin/mesquite ] || fail "Mesquite 不可用"
command -v sqlite3 >/dev/null 2>&1 || fail "sqlite3 不可用"
[ -x /sbin/initctl ] || fail "Upstart 不可用"

# 检查必需文件
for f in kindle-games-daemon.sh kindle-games.conf Launch-Kindle-Games.sh; do
  [ -f "$PKG/$f" ] || fail "缺少文件: $f"
done
for f in config.xml index.html style.css app.js; do
  [ -f "$PKG/waf/$f" ] || fail "缺少 WebView 文件: $f"
done

# 查找 appreg.db
for candidate in /var/local/appreg.db /opt/var/local/appreg.db; do
  [ -f "$candidate" ] && { APPREG="$candidate"; break; }
done
[ -n "$APPREG" ] || fail "appreg.db 未找到"

# 停止已有 WebView 实例
lipc-set-prop com.lab126.appmgrd stop "app://$APP_ID" >/dev/null 2>&1 || true
sleep 1

# 创建目录
mkdir -p "$BIN" "$WAF" || fail "无法创建目录"

# 停止旧守护进程
/sbin/initctl stop "$JOB" >/dev/null 2>&1 || true

# 复制守护进程
cp "$PKG/kindle-games-daemon.sh" "$BIN/kindle-games-daemon.sh" || fail "无法复制守护进程"
chmod 755 "$BIN/kindle-games-daemon.sh"

# 复制 WebView 文件
cp "$PKG/waf/"* "$WAF/" || fail "无法复制 WebView 文件"
for web_file in "$WAF/"*; do
  [ -f "$web_file" ] && chmod 644 "$web_file"
done

# 复制启动 Scriptlet 到 documents
cp "$PKG/Launch-Kindle-Games.sh" "$VIEWER" || fail "无法复制启动器"
chmod 755 "$VIEWER"

# 挂载根文件系统可写，安装 Upstart 配置
ROOT_RW=0
root_ro() {
  if [ "$ROOT_RW" -eq 1 ]; then
    mntroot ro >/dev/null 2>&1 || /usr/sbin/mntroot ro >/dev/null 2>&1 || /sbin/mntroot ro >/dev/null 2>&1 || true
    ROOT_RW=0
  fi
}
trap root_ro EXIT INT TERM HUP

if mntroot rw >/dev/null 2>&1 || /usr/sbin/mntroot rw >/dev/null 2>&1 || /sbin/mntroot rw >/dev/null 2>&1; then
  ROOT_RW=1
else
  fail "无法挂载根文件系统为可写"
fi

cp "$PKG/kindle-games.conf" "$CONF.new" || fail "无法安装 Upstart 配置"
chmod 644 "$CONF.new"
mv "$CONF.new" "$CONF" || fail "无法安装 Upstart 配置"
/sbin/initctl reload-configuration >/dev/null 2>&1 || true
root_ro
trap - EXIT INT TERM HUP

# 注册 WebView 应用到 appreg.db（正确的表结构）
sqlite3 "$APPREG" <<EOF
BEGIN IMMEDIATE;
INSERT OR IGNORE INTO interfaces(interface) VALUES('application');
INSERT OR IGNORE INTO handlerIds(handlerId) VALUES('$APP_ID');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','lipcId','$APP_ID');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','command','/usr/bin/mesquite -l $APP_ID -c file://$WAF/');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','supportedOrientation','U');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','unloadPolicy','unloadOnPause');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','extend-start','Y');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','maxLoadTime','60');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','maxGoTime','60');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','maxPauseTime','10');
INSERT OR REPLACE INTO properties(handlerId,name,value) VALUES('$APP_ID','maxUnloadTime','10');
COMMIT;
EOF
[ "$?" -eq 0 ] || fail "无法注册 WebView 应用到 appreg.db"

echo "$(date): appreg.db 注册成功" >> "$INSTALL_LOG"

# 启动守护进程
/sbin/initctl start "$JOB" >/dev/null 2>&1 || true

# 触发书架重新扫描
lipc-set-prop com.lab126.scanner doFullScan 1 >/dev/null 2>&1 || lipc-set-prop com.lab126.scanner triggerUpdate 1 >/dev/null 2>&1 || true

echo "$(date): 安装完成" >> "$INSTALL_LOG"
toast "游戏合集安装完成"
sync
exit 0
