#!/bin/sh
PKG_SRC="/mnt/us/kindle-games-package"
[ ! -d "$PKG_SRC" ] && for d in /mnt/us/*/kindle-games-package; do [ -d "$d" ] && { PKG_SRC="$d"; break; }; done
[ ! -d "$PKG_SRC" ] && { echo "找不到包目录"; exit 1; }
chmod 755 "$PKG_SRC/Install-Kindle-Games.sh"
"$PKG_SRC/Install-Kindle-Games.sh"
